from pathlib import Path
import math,json,copy,zipfile
import ezdxf
from ezdxf import bbox
from ezdxf.enums import TextEntityAlignment as TA
P=Path(__file__).resolve().parent;old=P.parent/'shengyuan_901_R2'
D=ezdxf.readfile(old/'shengyuan_901_R2_editable.dxf');D.styles.get('CJK').dxf.font='NotoSansCJK-Regular.ttc'
qa=json.loads((P.parent/'shengyuan_901'/'validation.json').read_text());F=qa['furniture_footprints'];xa=qa['pdf_calibration_x'];ya=qa['pdf_calibration_y']
def it(v,A):
 i=next((i for i in range(len(A)-1) if v<=A[i+1][0]),len(A)-2);a,b=A[max(0,i)],A[max(0,i)+1];return a[1]+(v-a[0])*(b[1]-a[1])/(b[0]-a[0])
def p(x,y):return it(x,xa),it(y,ya)
x0,Y=p(351.56,435.32);X,y0=p(465.44,522.56);room=(x0,y0,X,Y)
B=D.blocks['FURNITURE_DESIGN']
def within(e,r,tol=5):
 z=bbox.extents([e]);return z.has_data and z.extmin.x>=r[0]-tol and z.extmin.y>=r[1]-tol and z.extmax.x<=r[2]+tol and z.extmax.y<=r[3]+tol
# Remove original dressing-room furniture, not doors or source architecture.
for e in list(B):
 if within(e,room):B.delete_entity(e)
def line(a,b,l='R2-DETAIL'):B.add_line(a,b,dxfattribs={'layer':l})
def poly(a,l='A-FURN',close=False):B.add_lwpolyline(a,close=close,dxfattribs={'layer':l})
def box(x,y,w,h,l='A-FURN'):poly([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],l,True)
def txt(s,x,y,h=200):
 e=B.add_text(s,dxfattribs={'height':h,'style':'CJK','layer':'A-TEXT'});e.set_placement((x,y),align=TA.MIDDLE_CENTER);return e
new=[]
def add(name,x,y,w,h,typ):
 box(x,y,w,h,'A-CABINET' if typ=='cabinet' else 'A-FURN');new.append({'name':name,'room':'次卧','category':typ,'bounds':[x,y,x+w,y+h],'width':w,'depth':h});return x,y,x+w,y+h
# A 1500x2000 bed, head against left solid wall, retains the bay and both bedside aisles.
bx=x0+50;by=y0+600
add('次卧床1500×2000',bx,by,2000,1500,'bed')
box(bx+55,by+55,1890,1390);line((bx+450,by+80),(bx+450,by+1420))
for yy in [by+130,by+850]:box(bx+100,yy,300,520)
for yy in [by+180,by+240,by+1280]:poly([(bx+600,yy),(bx+1100,yy+30),(bx+1900,yy-10)],'R2-DETAIL')
add('次卧床头柜',bx,by+1630,450,450,'furniture');box(bx+40,by+1670,370,370)
# Sliding wardrobe leaves the original inward door swing free.
wx=X-600;wy=y0+130
add('C04 次卧移门衣柜',wx,wy,600,1800,'cabinet');line((wx+280,wy+40),(wx+280,wy+1760));line((wx+320,wy+40),(wx+320,wy+1760))
for yy in range(int(wy+150),int(wy+1700),180):poly([(wx+80,yy-60),(wx+520,yy),(wx+80,yy+60)],'R2-DETAIL')
txt('C04',wx+300,wy+900)
txt('次卧',x0+1800,Y-330,300);txt('1500×2000床 / 移门衣柜',x0+1800,Y-650)
# Update furniture record and maintain a measured circulation schedule.
F=[f for f in F if f['room']!='衣帽间']+new
# Main-bedroom wardrobe extended to 2800, same 600 depth, no change to original walls.
oldcab=next(f for f in F if f['name']=='C01');cx,cy,cX,cY=oldcab['bounds'];extended=(cx,cY-2800,cX,cY)
for e in list(B):
 if within(e,(cx-2,cy-2,cX+2,cY+2)):B.delete_entity(e)
box(cx,cY-2800,600,2800,'A-CABINET')
for yy in range(int(cY-2700),int(cY-100),180):poly([(cx+80,yy-60),(cX-80,yy),(cx+80,yy+60)],'R2-DETAIL')
line((cx+300,cY-2750),(cx+300,cY-50));txt('C01',cx+300,cY-1400)
oldcab['bounds']=list(extended);oldcab['depth']=2800
# Extra 1500-long wardrobe along the existing solid top wall, separated from the bay.
nx,ny=p(316.5,285.8);nr=(nx,ny-600,nx+1500,ny)
box(nx,ny-600,1500,600,'A-CABINET')
for xx in [nx+500,nx+1000]:line((xx,ny-600),(xx,ny))
for xx in range(int(nx+100),int(nx+1400),160):poly([(xx-50,ny-90),(xx,ny-510),(xx+50,ny-90)],'R2-DETAIL')
txt('C05',nx+750,ny-300);F.append({'name':'C05 主卧补充衣柜','room':'主卧','category':'cabinet','bounds':list(nr),'width':1500,'depth':600})
# Move the former dressing-room robot base into a distinct balcony service cabinet.
cx,cy=p(642,229.6);br=(cx,cy-650,cx+600,cy)
box(cx,cy-650,600,650,'A-CABINET');box(cx+60,cy-620,480,520,'A-APPLIANCE');txt('C08',cx+300,cy-325)
F.append({'name':'C08 阳台基站柜','room':'生活阳台','category':'cabinet','bounds':list(br),'width':600,'depth':650})
# Extend the television wall storage in its original footprint depth, without entering the corridor.
f=next(f for f in F if f['name']=='电视柜');r=f['bounds']
for e in list(B):
 if within(e,r):B.delete_entity(e)
tx,ty=p(554.7,300);box(tx,ty-2800,400,2800,'A-CABINET')
for yy in [ty-700,ty-1400,ty-2100]:line((tx,yy),(tx+400,yy))
f['name']='电视收纳墙';f['bounds']=[tx,ty-2800,tx+400,ty];f['depth']=2800
# Rebuild the quieter A03 furniture index to match the current bedroom.
idx=D.blocks['FURNITURE_INDEX'];idx.delete_all_entities()
for e in B:
 if e.dxftype()!='TEXT' or e.dxf.text in ['C01','C02','C03','C04','C05','C08','C09','C10','C11','C12']:idx.add_entity(e.copy())
# Coordinate tags are leaders only, not hidden installation routes.
def move_tag(name,anchor,label):
 b=D.blocks['EQUIPMENT_POINTS'];e=next(e for e in b.query('TEXT') if e.dxf.text==name);pos=e.dxf.insert
 for q in list(b.query('LWPOLYLINE')):
  pts=list(q.get_points());last=pts[-1]
  if abs(last[0]-pos.x)<2 and abs(last[1]-(pos.y-140))<2:
   first=pts[0]
   for c in list(b.query('CIRCLE')):
    if abs(c.dxf.center.x-first[0])<2 and abs(c.dxf.center.y-first[1])<2:b.delete_entity(c)
   b.delete_entity(q)
 e.set_placement(label,align=TA.MIDDLE_CENTER)
 b.add_circle(anchor,85,dxfattribs={'layer':'A-ELEC' if name.startswith('E') else 'A-WATER'})
 b.add_lwpolyline([anchor,(label[0],label[1]-140)],dxfattribs={'layer':'A-LEADER'})
move_tag('E14',p(650,240),p(643,258));move_tag('W03',p(650,244),p(640,218))
# Room usage changes propagate to every annotation and finish sheet.
replacements={'主卧+独立书房+独立衣帽储物间。':'主卧+次卧+独立书房，形成两卧一书房。','无儿童房，不新增固定客卧。':'次卧按成人客房布置，保留独立书房。','衣帽间设分类柜，飘窗前留空。':'次卧保留原飘窗，1500床与1800衣柜。','600深×2000日常衣柜':'600深×2800日常衣柜','C04 衣帽间：2600×600顶天挂衣柜。':'C04 次卧：1800长×600深移门衣柜。','C05 衣帽间：1750×600鞋包/抽屉柜。':'C05 主卧：1500长×600深补充衣柜。','C06 衣帽间：1180×600换季/行李柜。':'主卧床箱与衣柜顶柜补充换季收纳。','C07 衣帽间：1100×600分类储物柜。':'取消原衣帽间C06/C07，留足次卧通道。','C08 衣帽间：600宽家政基站柜。':'C08 阳台：600宽家政基站柜，防漏检修。','衣帽间电动帘':'次卧电动帘','独立衣帽间':'次卧','衣帽间':'次卧'}
for b in D.blocks:
 for e in b.query('TEXT'):
  s=e.dxf.text.replace('R2','R3')
  for a,z in replacements.items():s=s.replace(a,z)
  e.dxf.text=s
# Add bed sockets to the coordination conditions, away from wet areas.
b=D.blocks['EQUIPMENT_POINTS'];t=b.add_text('E23 次卧床头插座',dxfattribs={'height':200,'style':'CJK','layer':'A-ELEC'});t.set_placement((bx+800,Y-120),align=TA.MIDDLE_CENTER)
# New secondary-bedroom dimensions, all actual model measurements.
b=D.blocks['PLAN_DIMENSIONS']
for a,z,base,ang in [((bx,by+1500),(bx+2000,by+1500),(bx,by+1750),0),((bx+2000,by),(wx,by),(bx,by-250),0)]:
 dm=b.add_linear_dim(base=base,p1=a,p2=z,angle=ang,override={'dimtxt':200,'dimasz':100,'dimlfac':1,'dimdec':0,'dimtxsty':'CJK'},dxfattribs={'layer':'A-DIMS'});dm.render()
# Remove the old dressing-room water branch in A06 and move it to the balcony.
b=D.blocks['R2_WATER'];oldpoint=p(456,511);newpoint=p(650,244)
for e in list(b):
 if e.dxftype()=='LWPOLYLINE':
  q=list(e.get_points())[0]
  if abs(q[0]-oldpoint[0])<2 and abs(q[1]-oldpoint[1])<2:b.delete_entity(e)
 elif e.dxftype()=='CIRCLE' and (e.dxf.center.x-oldpoint[0])**2+(e.dxf.center.y-oldpoint[1])**2<4:b.delete_entity(e)
 elif e.dxftype()=='TEXT' and abs(e.dxf.insert.x-oldpoint[0])<2 and abs(e.dxf.insert.y-oldpoint[1]-260)<2:e.set_placement((newpoint[0],newpoint[1]+260),align=TA.MIDDLE_CENTER)
b.add_lwpolyline([newpoint,(newpoint[0],p(570,415)[1]),p(570,415)],dxfattribs={'layer':'R2-COLD'})
b.add_circle(newpoint,90,dxfattribs={'layer':'R2-COLD'})
# Center the guest-room ceiling light over the bed, not the former dressing-room center.
for e in D.blocks['R2_CEILING'].query('CIRCLE'):
 if abs(e.dxf.radius-150)<1 and x0<e.dxf.center.x<X and y0<e.dxf.center.y<Y:e.dxf.center=(bx+1000,by+750,0)
# Validate changed hard furniture against one another and source bearing rectangles.
def area(a,b):return max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
clashes=[]
for i,f in enumerate(F):
 for g in F[i+1:]:
  if f['room']==g['room'] and area(f['bounds'],g['bounds'])>2500:clashes.append([f['name'],g['name']])
assert not clashes,clashes
for f in new:assert f['bounds'][0]>=x0 and f['bounds'][1]>=y0 and f['bounds'][2]<=X and f['bounds'][3]<=Y
# Ensure new wardrobe starts beyond the original bedroom door's 800mm sweep.
hinge=p(462.32,431.6)
assert hinge[1]-new[-1]['bounds'][3]>800
clear={'次卧靠窗侧净宽':round(by-y0),'次卧上侧净宽':round(Y-(by+1500)),'次卧床尾至衣柜':round(wx-(bx+2000))}
assert min(clear.values())>=600,clear
D.saveas(P/'working.dxf')
(P/'validation_R3.json').write_text(json.dumps({'clashes':clashes,'guest_clearances_mm':clear,'footprints':F,'structural_changes':'none relative to R2','storage':'dedicated dressing room removed; storage capacity is reduced, compensated in main and guest wardrobes and lift-up beds','base_cabinet':'moved to balcony; site drainage and weatherproofing verification required'},ensure_ascii=False,indent=2))
print('Layout QA passed',clear,flush=True)
# Six A3 PDF pages and main plan preview.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from ezdxf.addons.drawing import Frontend,RenderContext
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,BackgroundPolicy,ColorPolicy
with PdfPages(P/'shengyuan_901_R3.pdf') as pdf:
 for i in range(6):
  fig=plt.figure(figsize=(420/25.4,297/25.4));ax=fig.add_axes([0,0,1,1])
  Frontend(RenderContext(D),MatplotlibBackend(ax),config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK,min_lineweight=.09)).draw_layout(D.modelspace(),finalize=True)
  fig.set_size_inches(420/25.4,297/25.4);ax.set_aspect('equal',adjustable='box');ax.set_xlim(-4600+i*40000,29000+i*40000);ax.set_ylim(-4300,19460)
  pdf.savefig(fig)
  if i==1:fig.savefig(P/'R3_plan_preview.png',dpi=150)
  plt.close(fig)
print('PDF ready',flush=True)
# Font-independent file uses glyph outlines and static dimension blocks.
from ezdxf.addons import text2path,MTextExplode
O=copy.deepcopy(D)
for block in O.blocks:
 with MTextExplode(block) as exp:
  for e in list(block.query('MTEXT')):exp.explode(e)
 for e in list(block.query('TEXT')):text2path.explode(e,target=block)
 for e in list(block.query('DIMENSION')):block.add_blockref(e.dxf.geometry,(0,0));block.delete_entity(e)
for s in O.styles:s.dxf.font='txt.shx';s.dxf.bigfont=''
assert not O.audit().errors
O.saveas(P/'shengyuan_901_R3_font_independent.dxf')
D.styles.get('CJK').dxf.font='simsun.ttc';assert not D.audit().errors;D.saveas(P/'shengyuan_901_R3_editable.dxf')
(P/'working.dxf').unlink();print('CAD files ready',flush=True)
