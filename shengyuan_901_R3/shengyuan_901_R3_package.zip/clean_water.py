from pathlib import Path
import zipfile
import ezdxf,fitz
P=Path(__file__).resolve().parent
for filename in ['shengyuan_901_R3_editable.dxf','shengyuan_901_R3_font_independent.dxf']:
 D=ezdxf.readfile(P/filename)
 for e in D.blocks['R2_WATER'].query('LWPOLYLINE'):
  if len(e)==4:e.set_points(list(e.get_points())[:3])
 assert not D.audit().errors
 D.saveas(P/filename)
D=ezdxf.readfile(P/'shengyuan_901_R3_editable.dxf');D.styles.get('CJK').dxf.font='NotoSansCJK-Regular.ttc'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import Frontend,RenderContext
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,BackgroundPolicy,ColorPolicy
fig=plt.figure(figsize=(420/25.4,297/25.4));ax=fig.add_axes([0,0,1,1])
Frontend(RenderContext(D),MatplotlibBackend(ax),config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK,min_lineweight=.09)).draw_layout(D.modelspace(),finalize=True)
fig.set_size_inches(420/25.4,297/25.4);ax.set_aspect('equal',adjustable='box');ax.set_xlim(195400,229000);ax.set_ylim(-4300,19460);fig.savefig(P/'waterpage.pdf');plt.close(fig)
a=fitz.open(P/'shengyuan_901_R3.pdf');b=fitz.open(P/'waterpage.pdf');a.delete_page(5);a.insert_pdf(b,start_at=5);a.save(P/'final.pdf');a.close();b.close();(P/'final.pdf').replace(P/'shengyuan_901_R3.pdf');(P/'waterpage.pdf').unlink()
with zipfile.ZipFile(P/'shengyuan_901_R3_package.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in P.iterdir():
  if f.suffix in ['.dxf','.pdf','.png','.txt','.csv','.py','.json'] and f.name!='working.dxf':z.write(f,f.name)
with zipfile.ZipFile(P/'shengyuan_901_R3_package.zip') as z:assert z.testzip() is None
print('Old dressing-room water tail removed; final package verified.',flush=True)
