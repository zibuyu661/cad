from pathlib import Path
import json,copy,zipfile,csv
import ezdxf,fitz
from ezdxf.enums import TextEntityAlignment as TA
P=Path(__file__).resolve().parent
D=ezdxf.readfile(P/'shengyuan_901_R3_editable.dxf');D.styles.get('CJK').dxf.font='NotoSansCJK-Regular.ttc'
q=json.loads((P/'validation_R3.json').read_text());bed=next(f for f in q['footprints'] if f['name']=='次卧床1500×2000')['bounds'];x,y,X,Y=bed
for e in D.blocks['FURNITURE_DESIGN'].query('TEXT'):
 if e.dxf.text=='次卧':e.set_placement((x+1250,y+850),align=TA.MIDDLE_CENTER)
 if e.dxf.text=='1500×2000床 / 移门衣柜':e.dxf.text='床1500×2000';e.set_placement((x+1250,y+480),align=TA.MIDDLE_CENTER)
# Structural reference equality, excluding cosmetic annotation changes.
R2=ezdxf.readfile(P.parent/'shengyuan_901_R2'/'shengyuan_901_R2_editable.dxf')
for name in ['SOURCE_ORIGINAL','SOURCE_PROPOSED']:
 def sig(doc):return [e.dxfattribs() for e in doc.blocks[name] if e.dxftype()=='LINE']
 a,b=sig(R2),sig(D)
 assert len(a)==len(b)
 for m,n in zip(a,b):assert m['start']==n['start'] and m['end']==n['end']
q['structure_line_check']='Original and proposed source block lines unchanged from R2'
# All new hard footprints checked against original bearing-wall rectangles.
base=json.loads((P.parent/'shengyuan_901'/'validation.json').read_text());xa=base['pdf_calibration_x'];ya=base['pdf_calibration_y']
def it(v,A):
 i=next((i for i in range(len(A)-1) if v<=A[i+1][0]),len(A)-2);a,b=A[max(0,i)],A[max(0,i)+1];return a[1]+(v-a[0])*(b[1]-a[1])/(b[0]-a[0])
def area(a,b):return max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
for f in q['footprints']:
 for a,t,b,d in [(546.44,277.88,593.12,285.32),(546.44,285.32,554,398.36),(344,435.32,351.56,511.64),(317.12,504.08,344,511.64),(546.44,484.88,554,506.84),(518.24,506.84,554,514.4),(518.24,587.48,558.92,595.04)]:
  assert area(f['bounds'],[it(a,xa),it(d,ya),it(b,xa),it(t,ya)])<2500,f['name']
q['bearing_overlap_check']='PASS';q['audit_errors']=len(D.audit().errors);assert not q['audit_errors']
(P/'validation_R3.json').write_text(json.dumps(q,ensure_ascii=False,indent=2))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import Frontend,RenderContext
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,BackgroundPolicy,ColorPolicy
fig=plt.figure(figsize=(420/25.4,297/25.4));ax=fig.add_axes([0,0,1,1])
Frontend(RenderContext(D),MatplotlibBackend(ax),config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK,min_lineweight=.09)).draw_layout(D.modelspace(),finalize=True)
fig.set_size_inches(420/25.4,297/25.4);ax.set_aspect('equal',adjustable='box');ax.set_xlim(35400,69000);ax.set_ylim(-4300,19460)
fig.savefig(P/'R3_plan_preview.png',dpi=150);fig.savefig(P/'page2.pdf');plt.close(fig)
a=fitz.open(P/'shengyuan_901_R3.pdf');b=fitz.open(P/'page2.pdf');a.delete_page(1);a.insert_pdf(b,start_at=1);assert len(a)==6;a.save(P/'final.pdf');a.close();b.close();(P/'final.pdf').replace(P/'shengyuan_901_R3.pdf');(P/'page2.pdf').unlink()
from ezdxf.addons import text2path,MTextExplode
O=copy.deepcopy(D)
for block in O.blocks:
 with MTextExplode(block) as exp:
  for e in list(block.query('MTEXT')):exp.explode(e)
 for e in list(block.query('TEXT')):text2path.explode(e,target=block)
 for e in list(block.query('DIMENSION')):block.add_blockref(e.dxf.geometry,(0,0));block.delete_entity(e)
for s in O.styles:s.dxf.font='txt.shx';s.dxf.bigfont=''
assert not O.audit().errors
O.saveas(P/'shengyuan_901_R3_font_independent.dxf')
D.styles.get('CJK').dxf.font='simsun.ttc';D.saveas(P/'shengyuan_901_R3_editable.dxf')
with (P/'家具柜体清单_R3.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['名称','房间','图面X向尺寸mm','图面Y向尺寸mm']);w.writerows((f['name'],f['room'],f['width'],f['depth']) for f in q['footprints'])
with zipfile.ZipFile(P/'shengyuan_901_R3_package.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in P.iterdir():
  if f.suffix in ['.dxf','.pdf','.png','.txt','.md','.csv','.py','.json'] and f.name!='working.dxf':z.write(f,f.name)
with zipfile.ZipFile(P/'shengyuan_901_R3_package.zip') as z:assert z.testzip() is None
print('R3 final package and checks passed',flush=True)
