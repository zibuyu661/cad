from pathlib import Path
import json,math,random,copy
import ezdxf
from ezdxf.enums import TextEntityAlignment as TA
P=Path(__file__).resolve().parent;OLD=P.parent/'shengyuan_901'
D=ezdxf.readfile(OLD/'shengyuan_901_layout_R1.dxf');qa=json.loads((OLD/'validation.json').read_text());F=qa['furniture_footprints']
D.styles.get('CJK').dxf.font='NotoSansCJK-Regular.ttc'
for n,c,w in [('R2-DETAIL',7,13),('R2-FLOOR',8,9),('R2-CEILING',4,18),('R2-LIGHT',2,18),('R2-PLANT',3,13),('R2-HOT',1,18),('R2-COLD',5,18),('R2-LEGEND',7,18)]:D.layers.new(n,dxfattribs={'color':c,'lineweight':w})
B=D.blocks['FURNITURE_DESIGN']
def line(a,b,l='R2-DETAIL'):B.add_line(a,b,dxfattribs={'layer':l})
def poly(a,l='R2-DETAIL',closed=False):return B.add_lwpolyline(a,close=closed,dxfattribs={'layer':l})
def box(x,y,w,h,l='R2-DETAIL'):poly([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],l,True)
def circle(x,y,r,l='R2-DETAIL'):B.add_circle((x,y),r,dxfattribs={'layer':l})
def txt(s,x,y,h=200,l='A-TEXT'):
 e=B.add_text(s,dxfattribs={'layer':l,'height':h,'style':'CJK'});e.set_placement((x,y),align=TA.MIDDLE_CENTER);return e
# Replace simplistic cabinet crosses with modules and storage symbols.
for e in list(B):
 if e.dxftype()=='LWPOLYLINE' and e.dxf.layer=='A-CABINET' and len(e)==2:B.delete_entity(e)
for f in F:
 x,y,X,Y=f['bounds'];w=X-x;h=Y-y;n=f['name'];cat=f['category']
 if n.startswith('C') and len(n)==3:
  vertical=h>w;length=h if vertical else w;nmod=max(1,round(length/600))
  for j in range(1,nmod):
   if vertical:line((x,y+h*j/nmod),(X,y+h*j/nmod))
   else:line((x+w*j/nmod,y),(x+w*j/nmod,Y))
  if n in ['C01','C04','C06']:
   if vertical:
    line((x+w*.5,y+60),(x+w*.5,Y-60))
    for cy in range(int(y+160),int(Y-100),180):poly([(x+80,cy-70),(X-80,cy),(x+80,cy+70)])
   else:
    line((x+60,y+h*.5),(X-60,y+h*.5))
    for cx in range(int(x+160),int(X-100),180):poly([(cx-65,y+70),(cx,Y-70),(cx+65,y+70)])
  else:
   for j in range(nmod):
    if vertical:
     cy=y+h*(j+.5)/nmod;line((X-100,cy-60),(X-100,cy+60))
    else:
     cx=x+w*(j+.5)/nmod;line((cx-60,y+100),(cx+60,y+100))
 if n=='双人床':
  for dy in [180,250]:poly([(x+600,y+dy),(x+1000,y+dy+30),(X-100,y+dy-10)])
  poly([(x+600,Y-180),(x+1000,Y-210),(X-120,Y-170)])
 if n=='三人沙发':
  for cy in [y+550,y+1400,y+2250]:
   poly([(x+240,cy-260),(x+650,cy-220),(x+680,cy+230),(x+260,cy+270)],closed=True)
  line((x+150,y+150),(x+150,Y-150))
 if n.startswith('餐椅') or n.startswith('端餐椅') or n.startswith('书房座椅'):
  box(x+60,y+60,w-120,h-120);line((x+70,Y-40),(X-70,Y-40))
 if n=='餐桌':
  for cx in [x+350,x+1200]:
   for cy in [y+210,y+640]:circle(cx,cy,100);circle(cx+125,cy,28)
  circle(x+w/2,y+h/2,115)
 if n=='备课书桌':
  for cx in [x+550,x+1650]:
   box(cx-230,Y-280,460,65);box(cx-250,Y-470,500,150);circle(cx+350,Y-430,45)
 if n in ['主卫淋浴','次卫淋浴']:
  line((x+80,Y-150),(x+350,Y-150));circle(x+350,Y-150,60);box(x+w/2-45,y+80,90,90)
# Soft furnishings: plants in existing clear corners, confined within furniture/display space.
def plant(x,y,r):
 circle(x,y,r*.45,'R2-PLANT')
 for k in range(9):
  a=k*2*math.pi/9
  poly([(x,y),(x+r*.65*math.cos(a-.35),y+r*.65*math.sin(a-.35)),(x+r*math.cos(a),y+r*math.sin(a)),(x+r*.65*math.cos(a+.35),y+r*.65*math.sin(a+.35)),(x,y)],'R2-PLANT')
plant(11850,10600,180);plant(13500,5500,170)
# Update title notes and create improved secondary blocks.
for block in D.blocks:
 for e in block.query('TEXT'):
  e.dxf.text=e.dxf.text.replace('R1','R2').replace('平面方案','深化平面方案')
# Add discipline-specific sheets using the existing true-scale A3 frame.
# Geometry anchors come from the calibrated source used by R1.
xa=qa['pdf_calibration_x'];ya=qa['pdf_calibration_y']
def it(v,A):
 i=next((i for i in range(len(A)-1) if v<=A[i+1][0]),len(A)-2);a,b=A[max(0,i)],A[max(0,i)+1];return a[1]+(v-a[0])*(b[1]-a[1])/(b[0]-a[0])
def p(x,y):return(it(x,xa),it(y,ya))
ROOM={'主卧':(266.24,285.32,382.76,431.6),'书房':(386.6,285.32,492.44,395.24),'衣帽间':(351.56,435.32,465.44,522.56),'主卫':(266.24,435.32,344,504.08),'次卫':(496.16,285.32,546.44,356.24),'次卫干区':(496.16,360.32,546.44,394.52),'厨房':(469.28,435.32,546.44,506.84),'客餐厅':(554,285.32,706.16,506.84),'玄关':(525.68,513.8,593.48,587.48),'阳台':(515,228.92,706.16,277.88)}
def bounds(q):
 x,t=p(q[0],q[1]);X,b=p(q[2],q[3]);return x,b,X,t
# Replace the obsolete empty corner note field with concise annotation schedules.
def new_sheet(code,title,notes,offset,content):
 global B
 source=D.blocks['A03_SHEET'];B=D.blocks.new(code+'_SHEET')
 # Reuse only the frame/title entities, not old notes or inserts.
 for e in source:
  if e.dxftype()=='INSERT':continue
  if e.dxftype()=='TEXT':
   pos=e.dxf.insert
   if pos.x>17500 and 0<pos.y<16500:continue
   if pos.x<17500 and pos.y<-1500:continue
  B.add_entity(e.copy())
 for e in B.query('TEXT'):
  e.dxf.text=e.dxf.text.replace('收纳设备及预留条件图',title).replace('A03',code)
 for j,s in enumerate(notes):
  e=txt(s,18200,15500-j*480,210,'R2-LEGEND');e.set_placement((18200,15500-j*480),align=TA.MIDDLE_LEFT)
 txt(title+'  1:80',6000,-3150,400)
 B.add_blockref('SOURCE_PROPOSED',(0,1800));B.add_blockref(content,(0,1800))
 D.modelspace().add_blockref(B.name,(offset,0))
 l=D.layouts.new(code);l.page_setup(size=(420,297),margins=(0,0,0,0),units='mm')
 l.add_viewport(center=(210,148.5),size=(420,297),view_center_point=(offset+12200,7580),view_height=23760)
# Flooring grid, each room bounded independently, no hatch bleeding through walls.
B=D.blocks.new('R2_FLOORING')
for name,q in ROOM.items():
 x,y,X,Y=bounds(q);wet=name in ['主卫','次卫','次卫干区','厨房','玄关','阳台'];step=600 if wet else (800 if name=='客餐厅' else 150)
 if wet or name=='客餐厅':
  for xx in range(int(x)+step,int(X),step):line((xx,y),(xx,Y),'R2-FLOOR')
  for yy in range(int(y)+step,int(Y),step):line((x,yy),(X,yy),'R2-FLOOR')
 else:
  for xx in range(int(x)+step,int(X),step):line((xx,y),(xx,Y),'R2-FLOOR')
  for j,xx in enumerate(range(int(x),int(X),step)):
   for yy in range(int(y)+600+(j%3)*300,int(Y),1200):line((xx,yy),(min(xx+step,X),yy),'R2-FLOOR')
 txt(name,(x+X)/2,(y+Y)/2+180,260)
 txt('600×600防滑砖' if wet else ('800×800浅色砖' if name=='客餐厅' else '150宽木地板'),(x+X)/2,(y+Y)/2-200)
 for v in [(x+100,y+100),(x+320,y+100),(x+100,y+320)]:line((x+100,y+100),v,'R2-FLOOR')
new_sheet('A04','地面铺装方案图',['铺装分格为方案排版，现场复尺后调整起铺点。','主卧/书房/衣帽间：浅木色地板。','客餐厅：800×800暖白或米色砖。','厨卫/阳台/玄关：600×600防滑砖。','湿区坡向现有地漏，标高与排水坡度待核。','门槛处收口与防水翻边另作节点。','本图不以矩形面积代替实际房屋净面积。'],120000,'R2_FLOORING')
# Ceiling proposal respects the 2.8m original height; no blanket deep troughs.
B=D.blocks.new('R2_CEILING')
for name,q in ROOM.items():
 x,y,X,Y=bounds(q);wet=name in ['厨房','主卫','次卫','次卫干区'];margin=180 if wet else 220
 box(x+margin,y+margin,X-x-2*margin,Y-y-2*margin,'R2-CEILING')
 if not wet:
  box(x+margin+80,y+margin+80,X-x-2*margin-160,Y-y-2*margin-160,'R2-CEILING')
 for xx in [x+(X-x)*.25,x+(X-x)*.75]:
  for yy in [y+(Y-y)*.25,y+(Y-y)*.75]:circle(xx,yy,55,'R2-LIGHT');line((xx-100,yy),(xx+100,yy),'R2-LIGHT');line((xx,yy-100),(xx,yy+100),'R2-LIGHT')
 if wet:
  box((x+X)/2-200,(y+Y)/2-200,400,400,'R2-LIGHT')
 else:
  circle((x+X)/2,(y+Y)/2,150,'R2-LIGHT')
 txt(name,(x+X)/2,(y+Y)/2+450,260)
 txt('集成吊顶/检修口待定' if wet else '原顶为主/局部简洁线框',(x+X)/2,(y+Y)/2-480)
new_sheet('A05','吊顶灯位方案图',['原始层高2800，梁H400处先核梁底净高。','居室原顶为主，局部浅吊顶与法式线框。','厨卫集成吊顶；浴霸/排气需检修。','灯位为方案中心线，回路及标高待深化。','圆：主灯；小圆十字：筒灯；方：集成设备。','不直接套用参考图250/300mm全屋降顶。','窗帘盒及检修间距按实际电机复尺。'],160000,'R2_CEILING')
# Water supply routes are above-ceiling conceptual coordination, not concealed floor routing.
B=D.blocks.new('R2_WATER')
# Two riser reference corridors connect equipment groups; do not imply drilling beams.
spine=[p(570,575),p(570,415),p(450,415),p(450,460)]
poly(spine,'R2-COLD');poly([(x+120,y+120) for x,y in spine],'R2-HOT')
for x,y in [(280,449),(505,497),(535,380),(690,245),(456,511)]:
 X,Y=p(x,y);join=p(570,415);poly([(X,Y),(X,join[1]),join],'R2-COLD');circle(X,Y,90,'R2-COLD')
 txt('预留用水点',X,Y+260)
new_sheet('A06','给水协调条件示意图',['红：热水条件；蓝：冷水条件。','线路仅为吊顶内协调示意，不是敷设定位。','现有入水/热水器位置和压力须现场确认。','经过梁区应避梁绕行，不得按线穿梁开孔。','管径/阀门/保温/回路和排水坡度另行深化。','阳台污废水系统核实后才可接洗衣机。','扫地基站设防漏托盘、止回及检修。','不把示意线路当作隐蔽工程施工依据。'],200000,'R2_WATER')
# Keep a quiet black CAD background preview but printable white PDF.
D.set_modelspace_vport(height=28000,center=(112000,7580))
# Render before replacing the font with the Windows-native name.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from ezdxf.addons.drawing import Frontend,RenderContext
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,BackgroundPolicy,ColorPolicy
with PdfPages(P/'shengyuan_901_R2.pdf') as pdf:
 for i in range(6):
  fig=plt.figure(figsize=(420/25.4,297/25.4));ax=fig.add_axes([0,0,1,1])
  Frontend(RenderContext(D),MatplotlibBackend(ax),config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK,min_lineweight=.09)).draw_layout(D.modelspace(),finalize=True)
  fig.set_size_inches(420/25.4,297/25.4);ax.set_aspect('equal',adjustable='box');ax.set_xlim(-4600+i*40000,29000+i*40000);ax.set_ylim(-4300,19460)
  pdf.savefig(fig)
  if i==1:fig.savefig(P/'R2_plan_preview.png',dpi=150)
  plt.close(fig)
 print('PDF complete',flush=True)
# Font-independent companion: explode visible text into filled glyph paths.
from ezdxf.addons import text2path
OUTLINE=copy.deepcopy(D);count=0
for block in OUTLINE.blocks:
 for e in list(block):
  if e.dxftype()=='TEXT':text2path.explode(e,target=block);count+=1
OUTLINE.saveas(P/'shengyuan_901_R2_font_independent.dxf')
D.styles.get('CJK').dxf.font='simsun.ttc'
# Explicit DXF Unicode escapes remove dependence on local UTF-8/ANSI import settings.
D.saveas(P/'shengyuan_901_R2_editable.dxf')
for f in ['shengyuan_901_R2_editable.dxf','shengyuan_901_R2_font_independent.dxf']:
 r=ezdxf.readfile(P/f);a=r.audit();assert not a.errors
print('QA PASS; outlined text count',count,flush=True)
(P/'validation_R2.json').write_text(json.dumps({'audit_errors':0,'outlined_text_entities':count,'sheets':6,'source':'R1 unchanged architecture and hard furniture footprints','font':'simsun.ttc, native UTF-8 Chinese; companion glyph outlines','new_sheets':'flooring/ceiling/water conceptual, not construction MEP'},ensure_ascii=False,indent=2))
