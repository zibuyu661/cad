from pathlib import Path
import json,zipfile,shutil
import ezdxf,fitz
from ezdxf import bbox
P=Path(__file__).resolve().parent
for name in ['shengyuan_901_R2_editable.dxf','shengyuan_901_R2_font_independent.dxf']:
 d=ezdxf.readfile(P/name)
 for e in d.blocks['FURNITURE_DESIGN']:
  if e.dxf.layer=='R2-PLANT':
   ext=bbox.extents([e]);c=ext.center
   if abs(c.x-13200)<250 and abs(c.y-6400)<250:e.translate(300,-900,0)
 assert not d.audit().errors
 if 'font_independent' in name:
  from ezdxf.addons import MTextExplode,text2path
  for block in d.blocks:
   with MTextExplode(block) as exploder:
    for entity in list(block.query('MTEXT')):exploder.explode(entity)
   for entity in list(block.query('TEXT')):text2path.explode(entity,target=block)
  assert not any(e.dxftype() in ['TEXT','MTEXT'] for b in d.blocks for e in b)
 else:
  assert any(e.dxf.text=='主卧' for e in d.blocks['FURNITURE_DESIGN'].query('TEXT'))
  assert not any('?' in e.dxf.text for b in d.blocks for e in b.query('TEXT'))
 d.saveas(P/name)
# Regenerate the corrected second PDF page, retaining other five pages.
d=ezdxf.readfile(P/'shengyuan_901_R2_editable.dxf');d.styles.get('CJK').dxf.font='NotoSansCJK-Regular.ttc'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import Frontend,RenderContext
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,BackgroundPolicy,ColorPolicy
fig=plt.figure(figsize=(420/25.4,297/25.4));ax=fig.add_axes([0,0,1,1])
Frontend(RenderContext(d),MatplotlibBackend(ax),config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK,min_lineweight=.09)).draw_layout(d.modelspace(),finalize=True)
fig.set_size_inches(420/25.4,297/25.4);ax.set_aspect('equal',adjustable='box');ax.set_xlim(35400,69000);ax.set_ylim(-4300,19460)
fig.savefig(P/'R2_plan_preview.png',dpi=150);fig.savefig(P/'corrected_page.pdf');plt.close(fig)
a=fitz.open(P/'shengyuan_901_R2.pdf');b=fitz.open(P/'corrected_page.pdf');a.delete_page(1);a.insert_pdf(b,start_at=1);a.save(P/'final.pdf');a.close();b.close();(P/'final.pdf').replace(P/'shengyuan_901_R2.pdf');(P/'corrected_page.pdf').unlink()
q=json.loads((P/'validation_R2.json').read_text());q['font']='Native Chinese UTF-8; simsun.ttc editable file; no TEXT or MTEXT in font-independent file';q['unintended_question_marks']=0
(P/'validation_R2.json').write_text(json.dumps(q,ensure_ascii=False,indent=2))
for name in ['furniture_schedule.csv','equipment_schedule.csv','客户需求落实表.csv','设计说明与使用方法.md']:shutil.copy2(P.parent/'shengyuan_901'/name,P/name)
with zipfile.ZipFile(P/'shengyuan_901_R2_package.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in P.iterdir():
  if f.suffix in ['.dxf','.pdf','.png','.txt','.csv','.md','.json','.py']:z.write(f,f.name)
with zipfile.ZipFile(P/'shengyuan_901_R2_package.zip') as z:assert z.testzip() is None
print('Final files and package verified.',flush=True)
