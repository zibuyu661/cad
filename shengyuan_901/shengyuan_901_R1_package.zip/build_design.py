"""Residential layout R1. Source geometry is extracted from the supplied vector PDF.
No raster tracing or AI image generation. Original DWG is never modified.
PDF plotted geometry is calibrated against explicit dimension chains, in millimetres.
"""
from pathlib import Path
from collections import Counter
import json,math,hashlib,csv
import fitz,ezdxf
from ezdxf.enums import TextEntityAlignment as TA
OUT=Path(__file__).resolve().parent
SOURCE=next(Path('/workspace/attachments').rglob('*Model.pdf'))
PG=fitz.open(SOURCE)[0]
DOC=ezdxf.new('R2013',setup=True);DOC.units=4
DOC.header['$INSUNITS']=4;DOC.header['$MEASUREMENT']=1;DOC.header['$LUNITS']=2;DOC.header['$LUPREC']=0
DOC.header['$LTSCALE']=100
DOC.styles.new('CJK',dxfattribs={'font':'NotoSansCJK-Regular.ttc'})
LAYERS={'A-EX-WALL':(7,35),'A-EX-STRUCT':(7,50),'A-EX-WINDOW':(4,18),'A-EX-DOOR':(3,18),'A-EX-SERVICE':(6,13),'A-EX-BEAM':(8,13),'A-EX-REFERENCE':(8,13),'A-EX-OPENING':(8,13),'A-NEW-PART':(2,25),'A-NEW-DOOR':(3,18),'A-FURN':(7,18),'A-CABINET':(32,25),'A-APPLIANCE':(4,18),'A-SANITARY':(4,18),'A-CURTAIN':(6,13),'A-ELEC':(1,18),'A-WATER':(5,18),'A-DIMS':(7,13),'A-TEXT':(7,18),'A-LEADER':(8,13),'A-DEMO':(1,18),'A-SHEET':(7,35),'A-NOTE':(7,18),'A-RUG':(8,9),'A-CAB-UPPER':(32,13)}
for n,(c,w) in LAYERS.items():DOC.layers.new(n,dxfattribs={'color':c,'lineweight':w})
DOC.layers.get('A-CAB-UPPER').dxf.linetype='DASHED'
DOC.layers.get('A-EX-OPENING').dxf.linetype='DASHED'
for n in LAYERS:
 if n.startswith('A-EX-'):DOC.layers.get(n).dxf.flags=4
XANCH=[(234.56,-1006),(266.24,0),(351.56,2720),(382.76,3714),(465.44,6350),(492.44,7214),(525.68,8270),(593.48,10430),(706.16,14020)]
YANCH=[(228.92,11430),(277.88,9870),(285.32,9630),(398.36,6030),(431.6,4970),(504.08,2660),(509.96,2470),(587.48,0)]
def interp(v,anchors):
 i=next((j for j in range(len(anchors)-1) if v<=anchors[j+1][0]),len(anchors)-2)
 a,b=anchors[max(0,i)],anchors[max(0,i)+1]
 return a[1]+(v-a[0])*(b[1]-a[1])/(b[0]-a[0])
def p(x,y):return (interp(x,XANCH),interp(y,YANCH))
def attr(l):return {'layer':l}
B=None
footprints=[];doorsectors=[];source_line_records=[]
def ln(a,b,l='A-FURN'):return B.add_line(a,b,dxfattribs=attr(l))
def lp(pts,l='A-FURN',closed=False):return B.add_lwpolyline(pts,close=closed,dxfattribs=attr(l))
def src_line(a,b,l='A-FURN'):return ln(p(*a),p(*b),l)
def src_poly(pts,l='A-FURN',closed=False):return lp([p(*v) for v in pts],l,closed)
def text(s,x,y,h=230,l='A-TEXT',align=TA.MIDDLE_CENTER):
 h=max(h,200)
 e=B.add_text(s,dxfattribs={'height':h,'style':'CJK','layer':l});e.set_placement((x,y),align=align);return e
def st(s,x,y,h=230,l='A-TEXT',align=TA.MIDDLE_CENTER):return text(s,*p(x,y),h,l,align)
def rect_mm(x,y,w,h,l='A-FURN',name=None,room=None,category='furniture',register=True):
 # x,y are source PDF anchor coordinates; width/height are actual model mm.
 X,Y=p(x,y);pts=[(X,Y),(X+w,Y),(X+w,Y-h),(X,Y-h)];lp(pts,l,True)
 if name and register:footprints.append({'name':name,'room':room,'category':category,'bounds':[X,Y-h,X+w,Y],'width':w,'depth':h})
 return X,Y,w,h

def inset(r,margin=50,l='A-FURN'):
 x,y,w,h=r;lp([(x+margin,y-margin),(x+w-margin,y-margin),(x+w-margin,y-h+margin),(x+margin,y-h+margin)],l,True)
def ellipse(X,Y,rx,ry,l='A-FURN'):
 lp([(X+rx*math.cos(i*math.pi/24),Y+ry*math.sin(i*math.pi/24)) for i in range(49)],l,True)
def src_oval(x,y,rx,ry,l='A-FURN'):ellipse(*p(x,y),rx,ry,l)
def cabinet(id,x,y,w,h,room,front='bottom',note=''):
 r=rect_mm(x,y,w,h,'A-CABINET',id,room,'cabinet');X,Y,w,h=r
 lp([(X,Y),(X+w,Y-h)],'A-CABINET');lp([(X+w,Y),(X,Y-h)],'A-CABINET')
 # Labels kept short; cabinet specifications are in the side schedule.
 text(id,X+w/2,Y-h/2,150,'A-TEXT')
 return r

def appliance(id,x,y,w,h,room,kind='box',register=True):
 r=rect_mm(x,y,w,h,'A-APPLIANCE',id,room,'appliance',register);X,Y,w,h=r
 if kind in ['washer','dishwasher']:ellipse(X+w/2,Y-h/2,w*.30,h*.30,'A-APPLIANCE')
 if kind=='hob':
  for xx in [.3,.7]:ellipse(X+w*xx,Y-h*.5,w*.16,h*.2,'A-APPLIANCE')
 
 if id!='消毒':text(id,X+w/2,Y-h/2,110,'A-TEXT')
 return r

def sink(x,y,w,h,room,id,register=False):
 r=rect_mm(x,y,w,h,'A-SANITARY',id,room,'fixture',register);X,Y,w,h=r
 inset(r,60,'A-SANITARY');ln((X+w*.5,Y),(X+w*.5,Y-110),'A-SANITARY');return r

def toilet(x,y,room,id,facing='left'):
 r=rect_mm(x,y,700,400,'A-SANITARY',id,room,'fixture');X,Y,w,h=r
 ellipse(X+w*.40,Y-h/2,w*.33,h*.4,'A-SANITARY')
 lp([(X+w*.75,Y),(X+w*.75,Y-h)],'A-SANITARY')
 return r

def door(x,y,width,closed_angle,angle,id,room=''):
 X,Y=p(x,y);a=math.radians(closed_angle);delta=math.radians(angle)
 end=(X+width*math.cos(a+delta),Y+width*math.sin(a+delta));ln((X,Y),end,'A-NEW-DOOR')
 lp([(X+width*math.cos(a+delta*i/32),Y+width*math.sin(a+delta*i/32)) for i in range(33)],'A-NEW-DOOR')
 doorsectors.append({'id':id,'hinge':[X,Y],'radius':width,'angle':[closed_angle,closed_angle+angle]})

def dim(a,b,base,angle=0,layer='A-DIMS',label=None):
 kw={'base':base,'p1':a,'p2':b,'angle':angle,'override':{'dimlfac':1,'dimtxt':200,'dimasz':110,'dimexo':120,'dimexe':160,'dimgap':75,'dimtad':1,'dimdec':0,'dimtxsty':'CJK'},'dxfattribs':attr(layer)}
 if label is not None:kw['text']=label
 e=B.add_linear_dim(**kw);e.render();return e

def leader(s,x,y,tx,ty):
 a=p(x,y);b=p(tx,ty);c=(b[0]+450,b[1]);lp([a,b,c],'A-LEADER');text(s,c[0]+40,c[1]+90,160,'A-TEXT',TA.BOTTOM_LEFT)

# Original geometry. Preserve every architecture line from the PDF 0 layer in the crop.
DRAWINGS=PG.get_drawings()
# PDF solid wall hatches are micro-triangulated in a height-marker OCG. Restore their
# rectilinear polygon boundaries from the original outline edges, not from furniture.
BEARING=[[(546.44,277.88),(593.12,277.88),(593.12,285.32),(554,285.32),(554,398.36),(546.44,398.36)],[(344,435.32),(351.56,435.32),(351.56,511.64),(317.12,511.64),(317.12,504.08),(344,504.08)],[(546.44,484.88),(554,484.88),(554,514.4),(518.24,514.4),(518.24,506.84),(546.44,506.84)],[(518.24,587.48),(558.92,587.48),(558.92,595.04),(518.24,595.04)]]
BEARING_RECTS=[(546.44,277.88,593.12,285.32),(546.44,285.32,554,398.36),(344,435.32,351.56,511.64),(317.12,504.08,344,511.64),(546.44,484.88,554,506.84),(518.24,506.84,554,514.4),(518.24,587.48,558.92,595.04)]
def inside_crop(r):return 220<=r.x0 and r.x1<=720 and 210<=r.y0 and r.y1<=620

def path_to_dxf(d,l):
 for it in d['items']:
  if it[0]=='l':
   a,b=it[1:];ln(p(a.x,a.y),p(b.x,b.y),l)
  elif it[0]=='c':
   points=it[1:];pts=[]
   for i in range(25):
    t=i/24;s=1-t
    x=s**3*points[0].x+3*s*s*t*points[1].x+3*s*t*t*points[2].x+t**3*points[3].x
    y=s**3*points[0].y+3*s*s*t*points[1].y+3*s*t*t*points[2].y+t**3*points[3].y
    pts.append(p(x,y))
   lp(pts,l)
  elif it[0]=='qu':
   q=it[1];lp([p(v.x,v.y) for v in [q.ul,q.ur,q.lr,q.ll]],l,True)
  elif it[0]=='re':
   r=it[1];src_poly([(r.x0,r.y0),(r.x1,r.y0),(r.x1,r.y1),(r.x0,r.y1)],l,True)

def source_geometry(name,modified=False):
 global B
 B=DOC.blocks.new(name)
 for d in DRAWINGS:
  r=d['rect'];layer=d.get('layer');c=d.get('color')
  if not inside_crop(r):continue
  if layer=='0' and c in [(0.,0.,0.),(0.,0.,1.)]:
   # Source lintel/threshold projections across the annotated inner doorway are
   # overhead references, not a new floor-to-ceiling wall blocking the entrance.
   is_header=False
   if len(d['items'])==1 and d['items'][0][0]=='l':
    aa,bb=d['items'][0][1:]
    if abs(aa.y-bb.y)<.02 and (abs(aa.y-510.68)<.02 or abs(aa.y-513.8)<.02) and min(aa.x,bb.x)>553.9 and max(aa.x,bb.x)>593.4:is_header=True
   if is_header:
    path_to_dxf(d,'A-EX-OPENING');continue
   # Opening at the main bathroom is widened from plotted ~689 to 800 mm.
   # Remove only its short nonbearing wall-jamb pieces, shown on the alteration sheet.
   if modified:
    for it in d['items']:
     if it[0]!='l':continue
     a,b=it[1:];aa=(a.x,a.y);bb=(b.x,b.y)
     left=338.24;right=316.64+800/((p(351.56,431.6)[0]-p(266.24,431.6)[0])/(351.56-266.24))
     # Exact jamb coordinate derived by inverse below; final point is a true 800 mm opening.
     right=inverse_x(p(316.64,431.6)[0]+800)
     if abs(a.x-left)<.02 and abs(b.x-left)<.02 and min(a.y,b.y)>=431.59 and max(a.y,b.y)<=435.33:
      aa=(right,a.y);bb=(right,b.y)
     if abs(a.y-b.y)<.02 and 431.59<=a.y<=435.33:
      if abs(a.x-left)<.02:aa=(right,a.y)
      if abs(b.x-left)<.02:bb=(right,b.y)
     ln(p(*aa),p(*bb),'A-EX-WINDOW' if c==(0.,0.,1.) else 'A-EX-WALL')
   else:
    path_to_dxf(d,'A-EX-WINDOW' if c==(0.,0.,1.) else 'A-EX-WALL')
  elif layer=='户型':path_to_dxf(d,'A-EX-DOOR')
  elif layer=='标识':path_to_dxf(d,'A-EX-SERVICE')
 # Solid bearing polygons, identical on all sheets.
 for pts in BEARING:
  coords=[p(*q) for q in pts];lp(coords,'A-EX-STRUCT',True)
  h=B.add_hatch(color=256,dxfattribs=attr('A-EX-STRUCT'));h.paths.add_polyline_path(coords,is_closed=True)
 # Original beam locations from the source's yellow line geometry, no new beams.
 for d in DRAWINGS:
  if not inside_crop(d['rect']):continue
  c=d.get('color')
  if c and c[0]>.9 and c[1]>.7 and c[2]<.3 and d.get('layer')=='标识':path_to_dxf(d,'A-EX-BEAM')
 return B

def inverse_x(v):return interp(v,[(v,k) for k,v in XANCH])
def inverse_y(v):return interp(-v,sorted([(-v,k) for k,v in YANCH]))
BASE=source_geometry('SOURCE_ORIGINAL')
BASEM=source_geometry('SOURCE_PROPOSED',True)
# Base quantities from explicit source chains; top right source chain differs by 1 mm.
def source_dims():
 for y in [190,650]:
  vals=[(266.24,351.56),(351.56,465.44),(465.44,525.68),(525.68,593.48),(593.48,706.16)] if y>400 else [(234.56,266.24),(266.24,382.76),(382.76,492.44),(492.44,706.16)]
  for a,b in vals:dim(p(a,285.32 if y<400 else 587.48),p(b,285.32 if y<400 else 587.48),p(a,y))
 for a,b in [(234.56,706.16)]:dim(p(a,228.92),p(b,228.92),p(a,163))
 dim(p(266.24,587.48),p(706.16,587.48),p(266.24,674))
 for a,b in [(228.92,285.32),(285.32,398.36),(398.36,431.6),(431.6,504.08),(504.08,587.48)]:dim(p(266.24,b),p(266.24,a),p(175,b),90)
 dim(p(266.24,587.48),p(266.24,228.92),p(148,587.48),90)
 for a,b in [(228.92,277.88),(277.88,509.96),(509.96,587.48)]:dim(p(706.16,b),p(706.16,a),p(760,b),90)
 st('上链原注15025、6805；与下链共同端点闭合差1mm，本图实标15026、6806。',450,141,170,'A-NOTE')

# FURNITURE PLAN, true footprint sizes in mm.
B=DOC.blocks.new('FURNITURE_DESIGN')
# Master bedroom: 1.8m bed; vanity by bay; daily wardrobe and return privacy screen.
r=rect_mm(267.1,325,2000,1800,'A-FURN','双人床','主卧');inset(r,55)
X,Y,w,h=r;ln((X+450,Y),(X+450,Y-h));ln((X+450,Y-h/2),(X+1800,Y-h/2))
for yy in [Y-100,Y-950]:lp([(X+100,yy),(X+450,yy),(X+450,yy-750),(X+100,yy-750)],'A-FURN',True)
rect_mm(267.1,309,450,450,'A-FURN','左床头柜','主卧');rect_mm(267.1,383,450,450,'A-FURN','右床头柜','主卧')
cabinet('C01',363.9,300,600,2000,'主卧')
r=rect_mm(268,286.2,1200,450,'A-FURN','梳妆台','主卧');inset(r,40);src_oval(292,305,190,190)
# A full-height opaque return screen interrupts view from the en-suite to the bed.
r=rect_mm(298,408,1500,100,'A-NEW-PART','遮挡屏风','主卧','partition')
door(382.76,401.48,850,-90,-90,'D01')
door(316.64,431.6,800,0,-90,'D02')
st('主卧',335,388,320);st('床1800×2000 / 梳妆',324,399,200)
leader('屏风H1800',337,409,346,420)
# Independent study, no bed.
r=rect_mm(400,286.5,2200,650,'A-FURN','备课书桌','书房');inset(r,45)
for x in [418,452]:
 rr=rect_mm(x,312,500,500,'A-FURN',f'书房座椅{x}','书房');inset(rr,60)
cabinet('C02',387.2,309,350,2700,'书房');cabinet('C03',480,325,380,1450,'书房')
appliance('打印',480,325,360,420,'书房',register=False)
door(489.44,398.36,800,180,-90,'D03')
st('独立书房',440,366,320);st('双人备课 / 书籍文件',440,379,200)
# Dressing room with 7m+ nominal storage; bay is deliberately left unblocked.
cabinet('C04',352.1,436,2600,600,'衣帽间')
cabinet('C05',352.1,455,600,1750,'衣帽间')
cabinet('C06',446.6,465.5,600,1180,'衣帽间')
cabinet('C07',411,503.7,1100,600,'衣帽间')
cabinet('C08',446.6,503.7,600,550,'衣帽间')
door(462.32,431.6,800,180,90,'D04')
st('独立衣帽间',406,476,260);st('衣物 / 鞋包 / 囤货',406,489,200)
# Main bathroom, existing southwest wet room. Widen existing nonbearing north jamb only.
sink(267.4,439,550,900,'主卫','主卫台盆',True)
rect_mm(266.7,475.4,900,900,'A-SANITARY','主卫淋浴','主卫','fixture')
src_line((295,475.4),(295,503.6),'A-SANITARY');src_line((266.7,475.4),(295,475.4),'A-SANITARY')
toilet(321,481,'主卫','智能马桶01')
st('主卫',309,469,230);st('干湿分离',309,480,130)
# Public bathroom retained in upper service strip; basin outside wet room.
rect_mm(497,286,1560,900,'A-SANITARY','次卫淋浴','次卫','fixture')
src_line((497,314.2),(546,314.2),'A-SANITARY')
toilet(497,331,'次卫','智能马桶02')
door(499.4,356.24,900,0,-90,'D05')
sink(529,367,550,800,'次卫干区','次卫独立台盆',True)
st('次卫',522,322,200);st('独立干区',516,388,150)
# Kitchen. Everything stays within the existing lower central room, entry on its east.
# Fixed box in source NW corner is untouched.
rect_mm(527.4,436,600,2200,'A-CABINET','厨房右操作台','厨房','counter')
rect_mm(469.6,488,1840,600,'A-CABINET','厨房窗下操作台','厨房','counter')
appliance('灶',528.2,453,520,700,'厨房','hob',False)
sink(485.5,489.5,650,480,'厨房','厨房水槽')
appliance('洗碗',507.6,488,600,600,'厨房','dishwasher',False)
appliance('冰箱',483.4,436,800,700,'厨房')
cabinet('C09',469.6,460,600,650,'厨房')
appliance('消毒',469.6,460,600,600,'厨房',register=False)
# Upper-cabinet projection is separate and dashed, avoiding the source strong/weak box.
rect_mm(469.6,460,350,900,'A-CAB-UPPER',register=False)
rect_mm(535.4,436,350,450,'A-CAB-UPPER',register=False)
rect_mm(535.4,479,350,850,'A-CAB-UPPER',register=False)
rect_mm(535.4,453,350,750,'A-CAB-UPPER',register=False) # range hood projection
# Sliding glazed kitchen door follows existing side opening, no move or enlargement.
src_line((555.7,452.96),(555.7,484.88),'A-NEW-DOOR');src_line((557.2,452.96),(557.2,469),'A-NEW-DOOR')
for y in [453,469,485]:src_line((555,y),(558,y),'A-NEW-DOOR')
st('厨房',507,479,250)
# Entrance: low shoe cabinet under existing window, tall cabinet on solid east wall.
cabinet('C10',525.9,534,350,1400,'玄关');cabinet('C11',580.8,521,400,1400,'玄关')
st('原位玄关',559,570,210);st('双扇入户门保留',575,622,170)
# Living, dining. No change to enclosing walls.
r=rect_mm(676.2,311,950,2800,'A-FURN','三人沙发','客厅');inset(r,100)
X,Y,w,h=r
for yy in [Y-950,Y-1850]:ln((X+100,yy),(X+w-100,yy))
rect_mm(554.7,322,400,2000,'A-CABINET','电视柜','客厅','cabinet')
r=rect_mm(617.5,348,1050,550,'A-FURN','茶几','客厅');inset(r,50)
rect_mm(604,299,750,750,'A-FURN','休闲椅','客厅')
# Rug is decorative and excluded from hard collision tests.
rect_mm(584,317,2850,2700,'A-RUG',register=False)
st('客厅',629,386,340);st('电视 / 休闲阅读',629,399,200)
r=rect_mm(602,451,1600,850,'A-FURN','餐桌','餐厅');inset(r,50)
for xx in [610,640]:
 for yy in [435,480]:rect_mm(xx,yy,450,450,'A-FURN',f'餐椅{xx}-{yy}','餐厅')
for xx in [586,653]:rect_mm(xx,458,450,450,'A-FURN',f'端餐椅{xx}','餐厅')
cabinet('C12',687.2,437,600,2100,'餐厅')
st('餐厅',627,422,320);st('六人餐位',627,434,200)
# Balcony: housework at the existing right-hand drain, leisure on the other side.
appliance('洗衣',682.7,229.6,600,650,'生活阳台','washer')
sink(662.5,229.6,600,650,'生活阳台','洗衣盆',True)
rect_mm(657,254,1500,600,'A-APPLIANCE','晾衣架投影','生活阳台','overhead',False)
rect_mm(560,236,650,650,'A-FURN','阳台椅1','景观阳台')
rect_mm(611,239,650,650,'A-FURN','阳台椅2','景观阳台');src_oval(594,252,250,250)
st('休闲阳台',605,271,200);st('洗衣晾晒',680,271,180)
# Existing balcony opening is fitted with sliding doors, original window is retained.
for yy in [280.2,282.2]:src_line((593.12,yy),(686,yy),'A-NEW-DOOR')
src_line((639.5,280.2),(639.5,282.2),'A-NEW-DOOR')
# Motorized curtain track projections, all tagged rather than hiding source glass.
for a,b in [((268,289),(314,289)),((411,289),(464,289)),((355,517),(400,517)),((597,287),(682,287))]:
 src_line(a,b,'A-CURTAIN')
st('走道净1060',448,410,160)
FURN=B
# A03 uses a quieter furnishing outline so equipment tags remain legible.
INDEX=DOC.blocks.new('FURNITURE_INDEX')
for entity in FURN:
 if entity.dxftype()!='TEXT' or (entity.dxf.text.startswith('C') and len(entity.dxf.text)==3):INDEX.add_entity(entity.copy())
# Dimension block. Some inner checks are actual, not copied source labels.
B=DOC.blocks.new('SOURCE_DIMENSIONS');source_dims()
B=DOC.blocks.new('PLAN_DIMENSIONS');B.add_blockref('SOURCE_DIMENSIONS',(0,0))
for x,y,w,h in [(267.1,325,2000,1800),(400,286.5,2200,650),(602,451,1600,850)]:
 X,Y=p(x,y);dim((X,Y),(X+w,Y),(X,Y+230))
# Passage checks from selected real footprint edges.
X,Y=p(525.9,559);right=p(580.8,559)[0];dim((X+350,Y),(right,Y),(X,Y),0)
st('玄关柜间净宽',554,542,130)
# Secondary concept equipment points, not a permit-level MEP routing drawing.
B=DOC.blocks.new('EQUIPMENT_POINTS')
POINTS=[('E01',291,303,'梳妆镜灯/插座'),('E02',419,307,'书桌双位插座/网络'),('E03',480,331,'打印机独立插座'),('E04',321,487,'主卫智能马桶防溅插座'),('E05',505,335,'次卫智能马桶防溅插座'),('E06',272,447,'主卫镜灯'),('E07',543,379,'次卫镜灯'),('E08',497,301,'次卫浴霸三合一'),('E09',305,451,'主卫浴霸三合一'),('E10',506,497,'洗碗机/净水/处理器'),('E11',478,469,'消毒柜'),('E12',493,444,'冰箱'),('E13',690,239,'洗衣机插座与上下水'),('E14',456,511,'上下水扫地机器人基站'),('E15',315,286,'主卧电动帘'),('E16',466,286,'书房电动帘'),('E17',401,519,'衣帽间电动帘'),('E18',682,289,'客厅电动帘'),('E19',514,505,'厨房防潮电动卷帘'),('E20',267,469,'主卫防潮电动卷帘'),('E21',530,284,'次卫防潮电动卷帘'),('E22',543,453,'油烟机及原排烟道核查')]
TAG_POS={'E01':(300,301),'E02':(432,331),'E03':(450,351),'E04':(316,499),'E05':(524,345),'E06':(292,447),'E07':(517,386),'E08':(520,300),'E09':(303,460),'E10':(505,478),'E11':(496,465),'E12':(514,447),'E13':(680,297),'E14':(418,495),'E15':(341,265),'E16':(445,265),'E17':(416,540),'E18':(646,303),'E19':(500,536),'E20':(246,469),'E21':(558,267),'E22':(563,466)}
def point_tag(id,x,y,tx,ty,layer='A-ELEC'):
 X,Y=p(x,y);LX,LY=p(tx,ty)
 B.add_circle((X,Y),85,dxfattribs=attr(layer))
 lp([(X,Y),(LX,LY-140)],'A-LEADER');text(id,LX,LY,200,layer)
for id,x,y,desc in POINTS:point_tag(id,x,y,*TAG_POS[id])
for id,x,y,tx,ty in [('W01',493,498,481,527),('W02',690,245,648,245),('W03',456,516,446,540)]:
 point_tag(id,x,y,tx,ty,'A-WATER')
# Alteration overlay identifies the tiny original nonbearing jamb only.
B=DOC.blocks.new('ALTERATIONS')
xnew=inverse_x(p(316.64,431.6)[0]+800)
src_poly([(338.24,431.6),(xnew,431.6),(xnew,435.32),(338.24,435.32)],'A-DEMO',True)
point_tag('M01',340,434,294,423,'A-DEMO')
# Source note beam texts, not copied as micro-vector glyphs.
B=DOC.blocks.new('SOURCE_LABELS')
for x,y in [(538,262),(564,417),(564,470),(649,496)]:st('原梁 H400 W240',x,y,125,'A-EX-REFERENCE')
st('原门洞注1160×2100',577,507,125,'A-EX-REFERENCE')
# Paper frame in model; all three sheets are A3 landscape at actual 1:80.
FRAME=(-4600,-4300,29000,19460)
SHEETS=[]

def note_lines(title,lines,x=18200,y=15700):
 text(title,x,y,340,'A-NOTE',TA.MIDDLE_LEFT);y-=600
 for line in lines:
  text(line,x,y,210,'A-NOTE',TA.MIDDLE_LEFT);y-=400
 return y

def sheet_frame(code,title,notes,offset):
 global B
 block=DOC.blocks.new(code+'_SHEET');B=block
 x0,y0,x1,y1=FRAME;lp([(x0,y0),(x1,y0),(x1,y1),(x0,y1)],'A-SHEET',True)
 lp([(x0+400,y0+400),(x1-400,y0+400),(x1-400,y1-400),(x0+400,y1-400)],'A-SHEET',True)
 ln((17400,y0+400),(17400,y1-400),'A-SHEET')
 text('盛苑新街 5栋901',18200,18200,500,'A-NOTE',TA.MIDDLE_LEFT)
 text(title,18200,17350,440,'A-NOTE',TA.MIDDLE_LEFT)
 text('夫妻二人 / 现代轻法式 / 独立书房',18200,16700,230,'A-NOTE',TA.MIDDLE_LEFT)
 text('平面方案 R1 · 待业主及现场复核',18200,-2300,240,'A-NOTE',TA.MIDDLE_LEFT)
 text(f'{code}    A3    1:80    单位:mm',18200,-2850,260,'A-NOTE',TA.MIDDLE_LEFT)
 text('2026-11-04',18200,-3300,210,'A-NOTE',TA.MIDDLE_LEFT)
 text(title+'  1:80',6000,-3150,400)
 # Retain the north arrow direction shown by source PDF (toward page bottom).
 B.add_circle((15300,13700),550,dxfattribs=attr('A-SHEET'))
 h=B.add_hatch(color=256,dxfattribs=attr('A-SHEET'));h.paths.add_polyline_path([(15230,14230),(15370,14230),(15300,13200)],is_closed=True)
 text('原图北向',15300,12900,200)
 y=note_lines(notes[0],notes[1])
 DOC.modelspace().add_blockref(block.name,(offset,0))
 lay=DOC.layouts.new(code)
 lay.page_setup(size=(420,297),margins=(0,0,0,0),units='mm',scale=(1,1))
 # Model frame 33600x23760 displayed 420x297 => exactly 1:80.
 lay.add_viewport(center=(210,148.5),size=(420,297),view_center_point=(offset+(x0+x1)/2,(y0+y1)/2),view_height=23760)
 SHEETS.append({'code':code,'title':title,'offset':offset,'frame':FRAME})
 return block

b=sheet_frame('A01','原始结构校核图',('底图与尺寸依据',[
 '01 底图来自客户提供的矢量PDF。','02 外轮廓、梁、门窗及承重墙柱原位保留。','03 原始DWG保留原文件，未直接转换或改写。','04 坐标按原尺寸链分段校准，模型单位mm。','05 上链与下链同端闭合差1mm，待实测确认。','06 顶部原注15025；模型闭合15026。','07 右上原注6805；模型闭合6806。','08 其它已选尺寸链按原图闭合。','09 层高2800；卫生间下沉400。','10 多处原梁高400、宽240。','11 1160×2100为玄关上端门洞注记。','12 下端双扇入户门按源图保留。','13 原图未注明每个房间用途。','14 厨卫定位结合原燃气/排水点推定。','15 现场需复测窗台、梁底及管道口。','16 北针方向沿用原图，不据图面上下命名。']),0)
b.add_blockref('SOURCE_ORIGINAL',(0,0));b.add_blockref('SOURCE_LABELS',(0,0));b.add_blockref('SOURCE_DIMENSIONS',(0,0))

b=sheet_frame('A02','家具平面布置图',('设计与布置说明',[
 '01 主卧+独立书房+独立衣帽储物间。','02 无儿童房，不新增固定客卧。','03 主卧1800×2000床，1200梳妆台。','04 主卫门外1500屏风遮挡床视线。','05 书房2200双人桌，教师备课及打印。','06 主卧、书房原飘窗均保留。','07 衣帽间设分类柜，飘窗前留空。','08 厨房限定在原下部独立房间内。','09 窗下洗涤，右侧灶台，原侧门保留。','10 厨房冰箱/洗碗机/消毒柜均有位置。','11 玄关及入户门不移动、不扩轮廓。','12 玄关窗下鞋柜H≤900，避免遮窗。','13 右侧客餐厅，六人餐桌1600×850。','14 上部阳台右端洗衣晾晒，左部休闲。','15 阳台暂以软分区分开，不另封外墙。','16 两卫智能马桶、湿区及镜柜见A03。','17 主卫局部非承重门洞建议扩至800。','18 墙体性质确认后方可实施拆改。']),40000)
b.add_blockref('SOURCE_PROPOSED',(0,0));b.add_blockref('FURNITURE_DESIGN',(0,0));b.add_blockref('PLAN_DIMENSIONS',(0,0))

b=sheet_frame('A03','收纳设备及预留条件图',('柜体与设备索引',[
 'C01 主卧：600深×2000日常衣柜。','C02 书房：350深×2700封闭书柜。','C03 书房：380深×1450文件/打印柜。','C04 衣帽间：2600×600顶天挂衣柜。','C05 衣帽间：1750×600鞋包/抽屉柜。','C06 衣帽间：1180×600换季/行李柜。','C07 衣帽间：1100×600分类储物柜。','C08 衣帽间：600宽家政基站柜。','C09 厨房：600宽消毒柜/吊柜。','C10 玄关：350深×1400低鞋柜。','C11 玄关：400深×1400储物柜。','C12 餐厅：600深×2100餐边酒柜。','厨房柜/吊柜以电器实物复尺分隔。','浴室镜带化妆灯；两卫三合一浴霸。','厨卫集成吊顶，检修口避开设备。','净水、处理器位于水槽柜下。','W01厨房；W02洗衣；W03扫地基站。','E15—E21全屋电动帘/防潮卷帘预留。','M01 主卫门洞建议800，仅拆约111墙肢。','先核实非承重，不可擅拆。','本图为条件示意，不是施工机电定位图。']),80000)
b.add_blockref('SOURCE_PROPOSED',(0,0));b.add_blockref('FURNITURE_INDEX',(0,0));b.add_blockref('EQUIPMENT_POINTS',(0,0));b.add_blockref('ALTERATIONS',(0,0))
# Supplement small equipment legend at bottom free area of A03.
B=b
text('给排水/电气复核：基站设防漏托盘与可检修管路；排水坡度、通气及燃气连接须专业核验。',4500,-2400,190)
# Center the drawing group on each A3 sheet while preserving model geometry and scale.
for sh in SHEETS:
 for entity in DOC.blocks[sh['code']+'_SHEET']:
  if entity.dxftype()=='INSERT':
   old=entity.dxf.insert;entity.dxf.insert=(old.x,old.y+1800,old.z)
# Metadata and QA.
DOC.set_modelspace_vport(height=28000,center=(52000,7600))
DOC.layouts.delete('Layout1')
path=OUT/'shengyuan_901_layout_R1.dxf';DOC.saveas(path)
R=ezdxf.readfile(path);audit=R.audit()
assert not audit.errors
# Rectangular footprint overlap checks, excluding embedded appliances in worktops.
def area_inter(a,b):return max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
collisions=[]
for i,f in enumerate(footprints):
 for g in footprints[i+1:]:
  if f['room']!=g['room']:continue
  ar=area_inter(f['bounds'],g['bounds'])
  if ar>2500:collisions.append([f['name'],g['name'],round(ar)])
bearing_collisions=[]
for f in footprints:
 for q in BEARING_RECTS:
  x1,y1=p(q[0],q[1]);x2,y2=p(q[2],q[3]);r=[x1,y2,x2,y1]
  ar=area_inter(f['bounds'],r)
  if ar>2500:bearing_collisions.append([f['name'],round(ar)])

ROOMS={'主卧':(266.24,285.32,382.76,431.6),'书房':(386.6,285.32,492.44,395.24),'衣帽间':(351.56,435.32,465.44,522.56),'主卫':(266.24,435.32,344,504.08),'次卫':(496.16,285.32,546.44,356.24),'次卫干区':(496.16,360.32,546.44,394.52),'厨房':(469.28,435.32,546.44,506.84),'玄关':(525.68,513.8,593.48,587.48),'客厅':(554,285.32,706.16,506.84),'餐厅':(554,285.32,706.16,506.84),'生活阳台':(515,228.92,706.16,277.88),'景观阳台':(515,228.92,706.16,277.88)}
out_of_room=[]
for f in footprints:
 q=ROOMS[f['room']];left,top=p(q[0],q[1]);right,bottom=p(q[2],q[3]);a=f['bounds']
 if a[0]<left-5 or a[1]<bottom-5 or a[2]>right+5 or a[3]>top+5:out_of_room.append(f['name'])
# Point-grid tests include the sector interior, not merely the final open leaf.
sweep_collisions=[]
for doorinfo in doorsectors:
 hx,hy=doorinfo['hinge'];a1,a2=doorinfo['angle'];r=doorinfo['radius']
 for f in footprints:
  x1,y1,x2,y2=f['bounds'];hit=False
  for ai in range(1,90):
   angle=math.radians(a1+(a2-a1)*ai/90)
   for ri in range(1,26):
    dist=r*ri/25;xx=hx+dist*math.cos(angle);yy=hy+dist*math.sin(angle)
    if x1+10<xx<x2-10 and y1+10<yy<y2-10:hit=True;break
   if hit:break
  if hit:sweep_collisions.append([doorinfo['id'],f['name']])

def wall_signature(blockname):
 def r(v):return tuple(round(c,5) for c in (v.x,v.y))
 result=set()
 for e in R.blocks[blockname]:
  if e.dxftype()=='LINE' and e.dxf.layer in ['A-EX-WALL','A-EX-WINDOW']:
   result.add((e.dxf.layer,tuple(sorted((r(e.dxf.start),r(e.dxf.end))))))
 return result
original_lines=wall_signature('SOURCE_ORIGINAL');proposed_lines=wall_signature('SOURCE_PROPOSED')
removed=original_lines-proposed_lines;added=proposed_lines-original_lines
assert len(removed)==4 and len(added)==4,(len(removed),len(added))
assert all(k[0]=='A-EX-WALL' for k in removed|added)
print('Architecture changes: only 4 original jamb segments replaced by 4 segments.')
print('Room containment:',out_of_room,'Door sweep:',sweep_collisions)

assert not collisions,collisions
assert not bearing_collisions,bearing_collisions
assert not out_of_room,out_of_room
assert not sweep_collisions,sweep_collisions

report={'source_pdf_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source':'customer vector PDF; original DWG left unchanged','wall_line_count_original':len(original_lines),'changed_wall_segments':{'removed':list(removed),'added':list(added)},'units':'mm','sheets':SHEETS,'audit_errors':len(audit.errors),'audit_fixes':len(audit.fixes),'furniture_footprints':footprints,'footprint_overlaps':collisions,'room_boundary_exceedances':out_of_room,'sampled_door_sweep_overlaps':sweep_collisions,'bearing_wall_overlaps':bearing_collisions,'opening_modification':'Main bath nonbearing jamb proposed opening 800mm; requires verification','original_top_chain':[1006,3714,3500,6805],'model_top_chain':[1006,3714,3500,6806],'bottom_chain':[2720,3630,1920,2160,3590],'pdf_calibration_x':XANCH,'pdf_calibration_y':YANCH,'quality_limit':'No native DWG coordinate extraction or actual AutoCAD open test; PDF dimensions anchored; site verification required.'}
fmap={f['name']:f for f in footprints}
report['measured_clearances_mm']={
 '玄关两侧柜体间净宽':round(fmap['C11']['bounds'][0]-fmap['C10']['bounds'][2]),
 '主卧床尾至衣柜净宽':round(fmap['C01']['bounds'][0]-fmap['双人床']['bounds'][2]),
 '厨房消毒柜至右操作台通道':round(fmap['厨房右操作台']['bounds'][0]-fmap['C09']['bounds'][2]),
 '衣帽间左右柜体间净宽':round(fmap['C06']['bounds'][0]-fmap['C05']['bounds'][2]),
 '主卧床侧至屏风净距':round(fmap['双人床']['bounds'][1]-fmap['遮挡屏风']['bounds'][3])}
report['minimum_text_height_model_mm']=min(e.dxf.height for e in R.entitydb.values() if e.dxftype()=='TEXT' and e.is_alive)
report['plot_scale']='A3 full-size 1:80, viewport width 420mm / model width 33600mm'
(OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Audit:',len(audit.errors),'fixes:',len(audit.fixes),'footprints:',len(footprints));print('Overlaps:',collisions);print('Bearing overlaps:',bearing_collisions)
# Data tables provide reviewable actual furniture sizes and equipment requirements.
with (OUT/'furniture_schedule.csv').open('w',encoding='utf-8-sig',newline='') as file:
 w=csv.writer(file);w.writerow(['名称','房间','类别','图面X向尺寸mm','图面Y向尺寸mm'])
 for f in footprints:w.writerow([f['name'],f['room'],f['category'],f['width'],f['depth']])
with (OUT/'equipment_schedule.csv').open('w',encoding='utf-8-sig',newline='') as file:
 w=csv.writer(file);w.writerow(['编号','名称','位置说明'])
 for id,x,y,desc in POINTS:w.writerow([id,desc,'条件预留；最终定位按实物与机电深化'])
# Render exact DXF, three A3 PDFs plus readable preview PNGs.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from ezdxf.addons.drawing import RenderContext,Frontend
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,ColorPolicy,BackgroundPolicy
config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK,lineweight_scaling=.9,min_lineweight=.08)
with PdfPages(OUT/'shengyuan_901_layout_R1.pdf') as pdf:
 for sheet in SHEETS:
  fig=plt.figure(figsize=(420/25.4,297/25.4));ax=fig.add_axes([0,0,1,1])
  Frontend(RenderContext(R),MatplotlibBackend(ax),config=config).draw_layout(R.modelspace(),finalize=True)
  fig.set_size_inches(420/25.4,297/25.4);ax.set_aspect('equal',adjustable='box')
  x0,y0,x1,y1=FRAME;off=sheet['offset'];ax.set_xlim(x0+off,x1+off);ax.set_ylim(y0,y1)
  fig.savefig(OUT/(sheet['code']+'_preview.png'),dpi=150,facecolor='white');pdf.savefig(fig,facecolor='white');plt.close(fig)
print('Rendered DXF to three-page A3 PDF')
