"""Editable reconstruction from the image supplied in the conversation.
Image coordinates are manually interpreted, not an automatic vector extraction.
All model coordinates are millimetres. No external raster references required.
"""
from pathlib import Path
import math, random, json
import ezdxf
from ezdxf.enums import TextEntityAlignment
OUT=Path(__file__).resolve().parent
D=ezdxf.new('R2013',setup=True); D.units=4
D.header['$INSUNITS']=4; D.header['$MEASUREMENT']=1; D.header['$LUNITS']=2; D.header['$LUPREC']=0
M=D.modelspace()
layers={'A-WALL':(7,35),'A-COLUMN':(7,50),'A-GLAZ':(4,18),'A-DOOR':(3,18),'A-PARTITION':(2,25),'A-FURN':(7,18),'A-BAR':(6,25),'A-EQUIP':(4,18),'A-PLANT':(3,13),'A-AXIS':(8,13),'A-DIMS':(7,13),'A-TEXT':(7,18),'A-FLOOR':(8,9),'A-SHEET':(7,25),'A-NOTES':(1,18)}
for name,(color,lw) in layers.items(): D.layers.new(name,dxfattribs={'color':color,'lineweight':lw})
D.styles.new('CJK',dxfattribs={'font':'NotoSansCJK-Regular.ttc','bigfont':''})
# Nonuniform scan calibration: each visible grid interval maps to its labelled distance.
PX=[158,401,649,899,1151,1396]; XX=[0,6600,13200,19800,26400,32200]
def p(x,y):
 i=next((i for i in range(5) if x<=PX[i+1]),4); i=max(i,0)
 return (XX[i]+(x-PX[i])*(XX[i+1]-XX[i])/(PX[i+1]-PX[i]),(689-y)*11800/441)
def attrs(l): return {'layer':l}
def line(a,b,l='A-FURN'): M.add_line(p(*a),p(*b),dxfattribs=attrs(l))
def poly(points,l='A-FURN',close=False): M.add_lwpolyline([p(*a) for a in points],close=close,dxfattribs=attrs(l))
def box(x,y,w,h,l='A-FURN',solid=False):
 pts=[(x,y),(x+w,y),(x+w,y+h),(x,y+h)]
 poly(pts,l,True)
 if solid:
  H=M.add_hatch(color=256,dxfattribs=attrs(l)); H.paths.add_polyline_path([p(*a) for a in pts],is_closed=True)
def curve(pts,l='A-PARTITION'): M.add_spline([p(*a) for a in pts],dxfattribs=attrs(l))
def ellipse(x,y,rx,ry=None,l='A-FURN',rot=0):
 ry=rx if ry is None else ry
 pts=[]
 for i in range(49):
  a=2*math.pi*i/48; xx=rx*math.cos(a); yy=ry*math.sin(a); r=math.radians(rot)
  pts.append((x+xx*math.cos(r)-yy*math.sin(r),y+xx*math.sin(r)+yy*math.cos(r)))
 poly(pts,l,True)
def text(s,x,y,h=13,l='A-TEXT',align=TextEntityAlignment.MIDDLE_CENTER):
 e=M.add_text(s,dxfattribs={'layer':l,'height':h*26.5,'style':'CJK'}); e.set_placement(p(x,y),align=align); return e
def chair(x,y,a=0,size=8):
 # Rounded seat and a separate backrest; all geometry remains editable.
 r=math.radians(a)
 def t(u,v): return (x+u*math.cos(r)-v*math.sin(r),y+u*math.sin(r)+v*math.cos(r))
 pts=[t(-size,-size*.55),t(-size*.8,-size),t(size*.8,-size),t(size,-size*.55),t(size,size*.65),t(size*.6,size),t(-size*.6,size),t(-size,size*.65)]
 poly(pts,'A-FURN',True); poly([t(-size-2,-size*.5),t(-size-2,-size-3),t(size+2,-size-3),t(size+2,-size*.5)])
def table(x,y,r=20,n=4,rot=0):
 ellipse(x,y,r,r*.85)
 for i in range(n):
  a=rot+360*i/n; ar=math.radians(a)
  chair(x+(r+13)*math.cos(ar),y+(r+13)*math.sin(ar),a-90)
def longtable(x,y,w,h,rot=0):
 r=math.radians(rot)
 def t(u,v):return(x+u*math.cos(r)-v*math.sin(r),y+u*math.sin(r)+v*math.cos(r))
 poly([t(-w/2,-h/2),t(w/2,-h/2),t(w/2,h/2),t(-w/2,h/2)],close=True)
 n=max(2,int(w/24))
 for i in range(n):
  u=-w/2+(i+.5)*w/n
  chair(*t(u,-h/2-12),rot); chair(*t(u,h/2+12),rot+180)
def door(x,y,length=36,ang=0,swing=90):
 r=math.radians(ang); r2=math.radians(ang+swing)
 line((x,y),(x+length*math.cos(r2),y+length*math.sin(r2)),'A-DOOR')
 pts=[(x+length*math.cos(r+(r2-r)*i/16),y+length*math.sin(r+(r2-r)*i/16)) for i in range(17)]
 poly(pts,'A-DOOR')
# Perimeter walls, glazing and interrupted entrance.
for y in (240,688):
 for a,b in [(158,325),(345,464),(585,819),(840,963),(1072,1167),(1239,1296),(1354,1396)]:
  box(a,y,b-a,8,'A-WALL')
 for a,b in [(325,345),(464,585),(819,840),(963,1072),(1167,1239),(1296,1354)]:
  for yy in (y+1,y+4,y+7):line((a,yy),(b,yy),'A-GLAZ')
for ya,yb in [(248,420),(509,689)]:
 box(147,ya,10,yb-ya,'A-WALL')
 for yy in range(ya+5,yb,60):line((148,yy),(156,yy),'A-GLAZ')
box(1396,248,12,441,'A-WALL')
for x in PX:
 for y in (248,689):box(x-12,y-12,25,29,'A-COLUMN',True)
# Entry doors, top service access and staff entry.
door(154,421,42,90,-90); door(154,507,42,-90,90)
door(1206,241,36,180,90); door(1206,241,36,0,-90)
door(1396,691,29,-90,-90)
# Right service rooms: continuous double partition and horizontal partitions.

for ya,yb in [(248,364),(399,476),(511,546),(581,590),(625,689)]:box(1238,ya,8,yb-ya,'A-WALL')
for ya,yb in [(248,392),(398,502),(509,623),(630,689)]:box(1246,ya,150,yb-ya,'A-FLOOR')
for y in (392,502,623):box(1246,y,150,7,'A-WALL')
for y in (364,476,546,590):
 # Mask-free representation of the door opening via panel line and swing.
 door(1247,y,35,90,-90)
text('后勤及设备区',1321,320,14);text('55m²',1321,339,13)
text('储物间',1322,449,13);text('卫生间',1322,565,13)
# Toilets, cubicles, washbasins.
for x in (1285,1324,1362):
 box(x,509,34,40,'A-EQUIP'); ellipse(x+17,530,8,11,'A-EQUIP');box(x+9,511,16,8,'A-EQUIP')
 box(x,585,34,38,'A-EQUIP');ellipse(x+17,607,8,11,'A-EQUIP');box(x+9,613,16,7,'A-EQUIP')
for y in (550,577):
 box(1363,y,32,26,'A-EQUIP');ellipse(1381,y+12,9,7,'A-EQUIP')
for x in (1282,1321,1360):
 line((x,509),(x,551),'A-WALL');line((x,584),(x,623),'A-WALL')
for y in range(269,389,6):
 if not 301 <= y <= 351:line((1250,y),(1392,y),'A-FLOOR')
for y in range(404,502,8):
 if not 433 <= y <= 464:line((1250,y),(1392,y),'A-FLOOR')
for y in range(637,687,7):line((1250,y),(1392,y),'A-FLOOR')
# Organic CAVE boundary, double spline enclosing main seating room.
outer=[(898,279),(972,267),(1052,270),(1135,288),(1202,314),(1229,374),(1231,455),(1223,533),(1195,606),(1156,658),(1085,684),(998,689),(914,681),(845,660),(815,616),(808,546),(793,472),(798,404),(820,347),(852,307),(898,279)]
curve(outer);curve([(x+(3 if x>1010 else -4),y+(4 if y>480 else -4)) for x,y in outer])
inner=[(896,316),(966,300),(1040,304),(1110,318),(1179,344),(1201,390),(1205,461),(1193,531),(1165,589),(1127,630),(1074,650),(1005,660),(939,650),(880,628),(849,583),(841,522),(826,469),(832,412),(851,365),(896,316)]
curve(inner,'A-FURN')
# Central floor rings and radial construction marks.
for rx,ry in [(83,88),(146,151),(177,175)]:
 e=[]
 for i in range(121):
  a=2*math.pi*i/120;e.append((1007+rx*math.cos(a),482+ry*math.sin(a)))
 # broken segments imitate diagram's dashed circular floor guides
 for i in range(0,120,3):poly(e[i:i+2],'A-FLOOR')
for a in range(0,360,45):
 r=math.radians(a);line((1007+65*math.cos(r),482+65*math.sin(r)),(1007+180*math.cos(r),482+180*math.sin(r)),'A-FLOOR')
line((998,523),(998,538),'A-DIMS');line((990,531),(1011,531),'A-DIMS');poly([(994,531),(998,537),(1002,531)],'A-DIMS');text('0.000',1019,521,9)
# Cave perimeter individual seats, interrupted for table groups and circulation.
for a in list(range(202,263,9))+list(range(270,311,9))+list(range(328,360,9))+list(range(0,41,9))+list(range(55,108,9))+list(range(128,182,9)):
 ar=math.radians(a);x=1007+190*math.cos(ar); y=479+191*math.sin(ar)
 if x<830:continue
 chair(x,y,a+90,9)
for x,y,r,n in [(1150,344,22,6),(860,601,22,5),(1156,575,22,4),(879,347,17,3)]:table(x,y,r,n,15)
# Upper island lounge and curving path.
curve([(658,249),(650,290),(663,346),(692,382),(666,419),(626,455),(632,492),(692,538),(737,572),(766,625),(774,688)],'A-PARTITION')
curve([(704,249),(691,278),(700,326),(726,359),(768,371),(824,343),(863,302),(900,279)],'A-PARTITION')
curve([(721,254),(708,280),(712,318),(738,350),(777,362),(815,345),(840,318),(834,286),(810,264),(770,255),(721,254)],'A-FURN')
table(770,308,24,7,0)
curve([(522,299),(566,303),(594,322),(613,359),(622,399),(606,438),(594,474)],'A-FURN')
curve([(514,313),(550,315),(576,337),(587,376),(578,415),(549,432),(510,425),(486,402),(479,368),(489,336),(514,313)],'A-FURN')
table(537,370,18,5,10)
# Public coffee area tables.
for args in [(212,356,22,6,0),(233,640,20,4,20),(278,657,16,4,0),(545,641,17,4,0),(592,657,15,3,20),(691,642,23,6,0)]:table(*args)
longtable(374,332,110,30,-12)
for x,y,a in [(207,278,0),(247,266,0),(285,273,0),(334,278,0),(373,267,0),(420,278,0),(461,279,0),(507,283,0),(575,288,40)]:
 chair(x,y,a,12);chair(x+17,y+19,a+180,10)
for x,y,a in [(185,542,-35),(204,574,-30),(227,609,-35),(522,673,0),(580,614,-20)]:chair(x,y,a,12)
# Coffee bar: rounded U-shaped counter, service inner zone and stools.
curve([(290,476),(279,493),(290,529),(314,553),(354,568),(421,573),(479,568),(512,551),(529,528),(526,504),(506,490)],'A-BAR')
curve([(306,480),(298,497),(311,524),(337,540),(380,550),(436,550),(479,545),(501,530),(505,512),(495,499)],'A-BAR')
curve([(320,477),(315,495),(330,516),(361,529),(421,534),(476,530),(490,520),(486,502)],'A-BAR')
box(322,475,110,52,'A-BAR');box(433,477,49,50,'A-BAR')
for x in (346,371,396):
 box(x,481,18,18,'A-EQUIP');ellipse(x+8,489,5,5,'A-EQUIP')
for x in (347,374,408,440,462):box(x,513,13,10,'A-EQUIP')
for x,y in [(447,488),(464,493),(487,483)]:ellipse(x,y,5,5,'A-EQUIP')
for x,y,a in [(277,478,-45),(270,500,-70),(280,522,-50),(291,542,-40),(311,560,-20),(334,573,-10),(355,579,0),(378,581,0),(400,582,0),(423,582,0),(445,581,0),(468,577,15),(491,569,25),(514,553,45),(531,531,75),(529,505,100)]:chair(x,y,a,6)
# Floor transitions: selected organic contours, no invented dense raster tracing.
for shift in (0,12,24):
 curve([(617+shift,257),(630+shift,308),(632+shift,353),(617+shift,396),(592+shift,427),(576+shift,461),(583+shift,494),(613+shift,525),(650+shift,546),(708+shift,560),(745+shift,600),(761+shift,645),(763+shift,686)],'A-FLOOR')
curve([(172,602),(227,639),(310,660),(384,665),(462,652),(527,624),(575,584),(606,563),(643,572),(660,602),(651,635),(613,666),(586,686)],'A-FLOOR')
# Plants / planting islands. Deterministic, symbolic vegetation, not exact species.
random.seed(12)
def plant(x,y,r=8):
 ellipse(x,y,r,r*.8,'A-PLANT')
 for a in range(0,360,60):
  ar=math.radians(a); curve([(x,y),(x+r*.75*math.cos(ar+.3),y+r*.75*math.sin(ar+.3)),(x+r*math.cos(ar),y+r*math.sin(ar))],'A-PLANT')
for x,y,w,h,n in [(132,270,15,128,12),(135,532,15,132,13),(174,253,186,9,18),(430,252,195,12,20),(579,566,52,61,18),(634,593,97,84,19),(1213,420,19,242,24),(752,352,29,57,8),(874,265,26,23,7)]:
 for _ in range(n):plant(x+random.random()*w,y+random.random()*h,random.uniform(4,9))
# Main labels.
for s,x,y,h in [('公共咖啡区',382,412,15),('85m²',382,430,13),('咖啡吧台区',398,608,14),('42m²',398,626,13),('过渡空间',696,484,14),('35m²',696,503,13),('CAVE沉浸式咖啡厅',1005,467,14),('130m²',1005,486,13)]:text(s,x,y,h)
text('主入口',50,465,14);poly([(102,458),(117,458),(117,449),(130,465),(117,481),(117,471),(102,471)],'A-TEXT',True)
text('员工通道',1463,651,13)
# Axis grid and actual editable dimensions.
for i,x in enumerate(PX):
 for ya,yb in [(107,202),(731,824)]:line((x,ya),(x,yb),'A-AXIS')
 for y in (98,835):ellipse(x,y,12,12,'A-AXIS');text(str(i+1),x,y,14)
for label,y in [('B',248),('A',689)]:
 for x in (39,1499):ellipse(x,y,12,12,'A-AXIS');text(label,x,y,14)
 line((51,y),(113,y),'A-AXIS');line((1429,y),(1487,y),'A-AXIS')
DIM={'dimlfac':1,'dimtxt':280,'dimasz':130,'dimexo':130,'dimexe':180,'dimgap':100,'dimtad':1,'dimclrd':7,'dimclre':7,'dimclrt':7,'dimdec':0,'dimtxsty':'CJK'}
for ypos in (169,764):
 for a,b in zip(PX,PX[1:]):
  dim=M.add_linear_dim(base=p(a,ypos),p1=p(a,248 if ypos<400 else 689),p2=p(b,248 if ypos<400 else 689),angle=0,override=DIM,dxfattribs=attrs('A-DIMS'));dim.render()
for ypos in (138,795):
 dim=M.add_linear_dim(base=p(158,ypos),p1=p(158,248 if ypos<400 else 689),p2=p(1396,248 if ypos<400 else 689),angle=0,override=DIM,dxfattribs=attrs('A-DIMS'));dim.render()
for x in (82,1455):
 dim=M.add_linear_dim(base=p(x,689),p1=p(158 if x<200 else 1396,689),p2=p(158 if x<200 else 1396,248),angle=90,override=DIM,dxfattribs=attrs('A-DIMS'));dim.render()
# North arrow and sheet title.
ellipse(108,927,26,26,'A-SHEET');poly([(108,901),(102,949),(108,939),(114,949)],'A-SHEET',True);text('N',108,889,17)
text('平面布置图 — 图片重绘',160,915,24,align=TextEntityAlignment.MIDDLE_LEFT)
line((159,938),(590,938),'A-SHEET');line((159,942),(590,942),'A-SHEET')
text('单位：mm  |  轴线 32200 × 11800  |  家具及曲线按图估绘',160,964,12,align=TextEntityAlignment.MIDDLE_LEFT)
text('尺寸冲突：原图底部33200；采用分段合计及顶部32200。施工前复核。',770,940,12,'A-NOTES',TextEntityAlignment.MIDDLE_LEFT)
text('房间面积沿用图片标注，未作测绘面积确认。右侧门洞位置及墙厚需复核。',770,964,11,'A-NOTES',TextEntityAlignment.MIDDLE_LEFT)
box(11,15,1514,992,'A-SHEET')
D.set_modelspace_vport(height=29000,center=(16000,5500))
path=OUT/'cafe_plan_editable.dxf';D.saveas(path)
# Verify reopened file, audit and record entity types / layer counts.
R=ezdxf.readfile(path);aud=R.audit()
from collections import Counter
report={'units':'mm','dxf_version':R.dxfversion,'entity_count':len(R.modelspace()),'entity_types':dict(Counter(e.dxftype() for e in R.modelspace())),'layers':dict(Counter(e.dxf.layer for e in R.modelspace())),'audit_errors':len(aud.errors),'audit_fixes':len(aud.fixes),'x_axis_dimensions':[6600,6600,6600,6600,5800],'overall_axis_dimensions':[32200,11800],'calibration':'Manual piecewise X calibration and linear Y calibration from the displayed image.'}
(OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
assert not aud.errors
assert not any(e.dxftype() in ('IMAGE','PDFUNDERLAY') for e in R.modelspace())
print(json.dumps(report,ensure_ascii=False))
# Render the exact DXF to a PDF and PNG for visual checking.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import RenderContext,Frontend
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,ColorPolicy,BackgroundPolicy
fig=plt.figure(figsize=(18,12));ax=fig.add_axes([0,0,1,1])
ctx=RenderContext(R);backend=MatplotlibBackend(ax)
config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK)
Frontend(ctx,backend,config=config).draw_layout(R.modelspace(),finalize=True)
fig.savefig(OUT/'cafe_plan_preview.png',dpi=150,facecolor='white')
fig.savefig(OUT/'cafe_plan_preview.pdf',facecolor='white')
print('DXF, preview PNG and PDF saved.')
