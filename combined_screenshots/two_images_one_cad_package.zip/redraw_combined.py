from pathlib import Path
import math,json,collections
import ezdxf
from ezdxf.enums import TextEntityAlignment as TA
OUT=Path(__file__).resolve().parent
D=ezdxf.new('R2013',setup=True);D.units=0
D.header['$INSUNITS']=0
D.styles.new('CJK',dxfattribs={'font':'NotoSansCJK-Regular.ttc'})
M=D.modelspace();sheet=1
for prefix in ['P1','P2']:
 for suffix,color,lw in [('FRAME',4,25),('STRUCTURE',1 if prefix=='P1' else 7,25),('DETAIL',30 if prefix=='P1' else 7,18),('FURN',2,13),('DOOR',4,13),('DIM',3,13),('TEXT',7,18),('NOTE',2,13)]:
  D.layers.new(prefix+'-'+suffix,dxfattribs={'color':color,'lineweight':lw})
def p(x,y):return(x+(800 if sheet==2 else 0),600-y)
def at(l):return {'layer':f'P{sheet}-{l}'}
def ln(a,b,l='DETAIL'):M.add_line(p(*a),p(*b),dxfattribs=at(l))
def poly(pts,l='DETAIL',close=False):M.add_lwpolyline([p(*q) for q in pts],close=close,dxfattribs=at(l))
def box(x,y,w,h,l='DETAIL'):poly([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],l,True)
def text(s,x,y,h=5,l='TEXT',align=TA.MIDDLE_CENTER):
 t=M.add_text(s,dxfattribs={'height':h,'style':'CJK','layer':f'P{sheet}-{l}'});t.set_placement(p(x,y),align=align)
def oval(x,y,rx,ry,l='DETAIL'):
 poly([(x+rx*math.cos(a*math.pi/20),y+ry*math.sin(a*math.pi/20)) for a in range(41)],l,True)
def circle(x,y,r,l='DIM'):M.add_circle(p(x,y),r,dxfattribs=at(l))
def dimline(a,b,label='待核',horizontal=True):
 ln(a,b,'DIM');x1,y1=a;x2,y2=b
 for x,y in [a,b]:ln((x-2,y+2),(x+2,y-2),'DIM')
 if horizontal:text(label,(x1+x2)/2,y1-3,2.8,'DIM')
 else:
  t=M.add_text(label,dxfattribs={'height':2.8,'rotation':90,'style':'CJK','layer':f'P{sheet}-DIM'});t.set_placement(p(x1-4,(y1+y2)/2),align=TA.MIDDLE_CENTER)
def door(x,y,w,a=0,s=90):
 end=math.radians(a+s);ln((x,y),(x+w*math.cos(end),y+w*math.sin(end)),'DOOR')
 poly([(x+w*math.cos(math.radians(a+s*i/20)),y+w*math.sin(math.radians(a+s*i/20))) for i in range(21)],'DOOR')
def furniture(x,y,w=8,h=5):box(x,y,w,h,'FURN');ln((x+1,y+1),(x+w-1,y+1),'FURN')
def frame():
 box(12,38 if sheet==1 else 56,680 if sheet==1 else 688,476 if sheet==1 else 496,'FRAME')
 box(24,50 if sheet==1 else 69,656 if sheet==1 else 663,452 if sheet==1 else 470,'FRAME')
# PLAN, manually interpreted from low resolution screenshot; no numeric dimensions inferred.
sheet=1;frame()
# Orthogonal plan structure, partitions and service strip.
box(93,134,207,150,'STRUCTURE')
for a,b in [((94,151),(269,151)),((94,176),(269,176)),((94,207),(269,207)),((199,207),(199,268)),((269,135),(269,284)),((94,268),(269,268)),((94,284),(300,284)),((269,175),(300,175)),((269,207),(300,207)),((269,237),(300,237))]:ln(a,b,'STRUCTURE')
# Top three bays and narrow fixtures.
for x in [230,242,255,281]:ln((x,135),(x,150),'DETAIL')
for x in range(219,265,8):box(x,134,5,12,'FURN')
for x in range(220,265,8):box(x,163,5,11,'FURN')
box(218,162,49,13,'DETAIL');box(214,135,53,16,'DETAIL')
# Public seating: rows of small units.
for row,yy in enumerate([140,153,166,179]):
 for xx in [99,112,125,138]:
  if row==3 and xx>120:continue
  furniture(xx,yy,8,5)
# Angled central counter with inner return.
poly([(178,150),(185,148),(190,170),(208,166),(213,174),(190,183),(185,180),(178,150)],'DETAIL')
poly([(183,151),(188,174),(193,178),(208,172)],'DETAIL')
poly([(190,148),(194,163),(202,161),(205,168)],'FURN')
# Stairs and polygon enclosure at lower-left.
poly([(94,221),(139,213),(161,257),(161,269),(94,257)],'DETAIL',True)
poly([(90,224),(94,259),(143,272),(162,273)],'DETAIL')
for x in range(104,143,5):box(x,220,3,29,'FURN')
for x in range(144,163,4):ln((x,265),(x,281),'DETAIL')
ln((98,252),(148,256),'DETAIL');ln((98,256),(150,260),'DETAIL')
# Lower central seating.
for yy in [216,228,240]:
 for xx in [209,225,241]:furniture(xx,yy,8,4)
# Right stair, small doors and plumbing marks.
for yy in [245,252,259,266]:ln((279,yy),(299,yy),'DETAIL')
box(278,242,21,27,'DETAIL');ln((272,210),(272,235),'DETAIL');ln((273,238),(298,238),'DETAIL')
for x in [277,285,293]:oval(x,193,2.5,3,'DOOR');ln((x,196),(x,204),'DOOR')
for x,y in [(124,212),(133,211),(174,267),(183,267),(278,272),(286,274)]:
 poly([(x-3,y),(x-3,y-5),(x+1,y-6),(x+3,y),(x+5,y)],'DOOR')
# Green dimension strings and axis bubbles (values unreadable).
for x in [93,269,300]:ln((x,83),(x,319),'DIM')
for y in [94,104,299,309]:
 for a,b in [(93,269),(269,300)]:dimline((a,y),(b,y))
for y in [134,151,176,207,268]:ln((40,y),(352,y),'DIM')
for x in [54,64,334,344]:
 for a,b in [(134,151),(151,176),(176,207),(207,268)]:dimline((x,a),(x,b),horizontal=False)
for i,y in enumerate([134,151,176,207,268]):
 for x in [40,352]:circle(x,y,4);text(str(i+1),x,y,3,'DIM')
for i,x in enumerate([93,269,300]):
 for y in [82,320]:circle(x,y,4);text(chr(65+i),x,y,3,'DIM')
text('图1  平面布置图（按截图比例重建）',40,363,8,align=TA.MIDDLE_LEFT)
text('尺寸数字不清，绿色标注“待核”；轴号仅为定位编号。',40,382,5,'NOTE',TA.MIDDLE_LEFT)
text('源图内容集中于左上角，此处保留原图框与构图关系。',40,396,5,'NOTE',TA.MIDDLE_LEFT)
text('单位未标定；不用于直接施工或按尺寸放样。',40,410,5,'NOTE',TA.MIDDLE_LEFT)
# SECOND SCREENSHOT, three elevations / sections and lower detail.
sheet=2;frame()
# Left irregular profile.
box(73,110,8,239,'DETAIL')
poly([(82,114),(165,114),(114,166),(116,183),(115,220),(114,258),(113,297),(126,328),(82,328)],'DETAIL')
poly([(82,114),(81,159),(77,183),(111,183)],'DETAIL')
poly([(85,186),(108,186),(106,208),(81,208)],'DETAIL')
poly([(86,225),(113,225),(111,244),(91,244),(86,225)],'DETAIL')
poly([(81,264),(103,264),(100,294),(82,294)],'DETAIL')
ln((82,299),(114,299),'DETAIL')
# Triangular lattice top.
poly([(92,115),(112,163),(164,115)],'DETAIL',True)
for a,b in [((99,130),(144,115)),((106,146),(132,115)),((102,116),(132,145)),((119,115),(143,133)),((111,162),(149,120))]:ln(a,b)
# Center folded screen profile and braces.
box(210,195,6,157,'DETAIL')
poly([(216,196),(262,196),(244,224),(253,239),(272,257),(300,285),(216,285)],'DETAIL',True)
poly([(220,203),(254,200),(218,221),(247,226),(220,239),(264,243),(221,258),(280,271),(221,281),(295,283)],'DETAIL')
for a,b in [((218,204),(243,224)),((220,220),(254,240)),((220,240),(274,257)),((220,259),(254,282)),((244,224),(219,258)),((253,239),(221,281)),((272,257),(241,282))]:ln(a,b)
# Lower inset and closely spaced members.
poly([(218,286),(243,286),(253,339),(219,339)],'DETAIL',True)
poly([(221,291),(239,291),(245,331),(221,321)],'DETAIL',True)
for x in range(222,242,3):ln((x,292),(x,322+(x-222)*.4),'DETAIL')
ln((222,325),(246,334),'DETAIL');ln((220,330),(250,338),'DETAIL')
# Right profile and ladder/shelf side view.
box(367,147,6,211,'DETAIL')
poly([(373,174),(414,174),(398,217),(394,358),(373,358)],'DETAIL',True)
ln((398,175),(398,218),'DETAIL')
for y in [219,260,283,302,319,339,351]:ln((373,y),(395 if y>219 else 398,y),'DETAIL')
for y in [285,306,323,343]:ln((373,y),(393,y),'DETAIL')
# Green extension/dimension strings.
for a,b in [((69,327),(69,362)),((77,327),(77,362)),((128,329),(128,362)),((205,148),(205,196)),((214,148),(214,195)),((263,148),(263,195)),((302,148),(302,286))]:ln(a,b,'DIM')
for x,y1,y2 in [(61,288,327),(194,332,354),(356,339,359)]:dimline((x,y1),(x,y2),horizontal=False)
for x,y in [(69,357),(78,357),(129,357),(204,155),(214,155),(267,154),(306,154)]:text('?',x,y,4,'DIM')
# Lower-left rounded rectangular detail, layered perimeter and internal diagonal lattice.
def rounded(x,y,w,h,r,l='DETAIL'):
 pts=[]
 for cx,cy,start in [(x+w-r,y+r,-90),(x+w-r,y+h-r,0),(x+r,y+h-r,90),(x+r,y+r,180)]:
  pts += [(cx+r*math.cos(math.radians(start+i*90/8)),cy+r*math.sin(math.radians(start+i*90/8))) for i in range(9)]
 poly(pts,l,True)
rounded(75,421,98,81,9)
rounded(79,426,90,72,5,'STRUCTURE')
rounded(84,432,79,61,3,'STRUCTURE')
box(95,439,67,47,'DETAIL');box(99,443,60,37,'DETAIL')
poly([(100,446),(112,465),(155,447),(115,479),(153,479),(158,448),(100,446)],'DETAIL')
for a,b in [((101,446),(115,479)),((101,463),(155,447)),((113,464),(113,478)),((117,463),(119,479))]:ln(a,b)
for x in range(84,165,3):ln((x,423),(x,428),'DETAIL')
for y in range(435,486,3):ln((76,y),(80,y),'DETAIL');ln((168,y),(172,y),'DETAIL')
for x in [83,164]:circle(x,491,5,'DIM');ln((x,472),(x,501),'DIM')
dimline((69,484),(69,501),horizontal=False)
text('图2  构件立面／剖面及局部示意',433,418,7,align=TA.MIDDLE_LEFT)
text('折线、框架及格栅为可编辑矢量。',433,439,5,'NOTE',TA.MIDDLE_LEFT)
text('数字无法可靠辨读，未填入猜测尺寸。',433,454,5,'NOTE',TA.MIDDLE_LEFT)
text('需原始DWG或至少一个已知尺寸校准。',433,469,5,'NOTE',TA.MIDDLE_LEFT)
# Independent paper-space tabs use the same two areas of one model.
for n,cx,cy,w,h in [('01_PLAN',352,324,730,550),('02_DETAILS',1155,296,730,550)]:
 lay=D.layouts.new(n);lay.page_setup(size=(420,297),margins=(10,10,10,10),units='mm')
 lay.add_viewport(center=(200,138.5),size=(390,270),view_center_point=(cx,cy),view_height=565)
D.set_modelspace_vport(height=650,center=(750,300))
f=OUT/'two_images_one_cad.dxf';D.saveas(f)
T=ezdxf.readfile(f);a=T.audit();assert not a.errors
assert not any(e.dxftype() in ['IMAGE','PDFUNDERLAY'] for e in T.modelspace())
r={'dxf_version':T.dxfversion,'units':'unitless; image proportions only','model_entities':len(T.modelspace()),'audit_errors':len(a.errors),'audit_fixes':len(a.fixes),'layouts':T.layout_names(),'layers':dict(collections.Counter(e.dxf.layer for e in T.modelspace()))}
(OUT/'validation.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(r)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import RenderContext,Frontend
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,ColorPolicy,BackgroundPolicy
from matplotlib.backends.backend_pdf import PdfPages
config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK,lineweight_scaling=1,min_lineweight=.1)
with PdfPages(OUT/'two_images_preview.pdf') as pdf:
 for s in [1,2]:
  fig=plt.figure(figsize=(12,9));ax=fig.add_axes([.02,.02,.96,.96]);Frontend(RenderContext(T),MatplotlibBackend(ax),config=config).draw_layout(T.modelspace(),finalize=True)
  fig.set_size_inches(12,9)
  offset=0 if s==1 else 800
  ax.set_xlim(offset,offset+720);ax.set_ylim(30,585);ax.set_aspect('equal',adjustable='box');fig.savefig(OUT/f'image{s}_preview.png',dpi=150,facecolor='white');pdf.savefig(fig,facecolor='white');plt.close(fig)
print('DXF and previews done')
