"""Four editable interior elevations reconstructed manually from supplied image.
Millimetres, 1:1 model geometry. Pictorial ceiling/landscape/furniture are estimates.
"""
from pathlib import Path
import math,random,json,collections
import ezdxf
from ezdxf.enums import TextEntityAlignment as TA
P=Path(__file__).resolve().parent
D=ezdxf.new('R2013',setup=True);D.units=4
D.header['$INSUNITS']=4;D.header['$MEASUREMENT']=1
D.styles.new('CJK',dxfattribs={'font':'NotoSansCJK-Regular.ttc'})
styles={'E-OUTLINE':(7,35),'E-CEILING':(7,18),'E-WALL':(7,25),'E-DOOR':(3,18),'E-GLASS':(4,13),'E-COLUMN':(7,30),'E-FURNITURE':(7,18),'E-BAR':(6,25),'E-EQUIPMENT':(4,13),'E-LANDSCAPE':(8,9),'E-PLANT':(3,13),'E-LIGHT':(2,13),'E-HATCH':(8,9),'E-TEXT':(7,18),'E-DIM':(7,13),'E-NOTES':(1,18),'E-SHEET':(7,25)}
for n,(c,w) in styles.items():D.layers.new(n,dxfattribs={'color':c,'lineweight':w})
M=D.modelspace();R=0
YTOP=[62,324,540,752];YBOT=[230,456,668,874]
# Each illustrated panel is calibrated separately to its stated 5900 height.
def p(x,y):return ((x-106)*32200/1492,(YBOT[R]-y)*5900/(YBOT[R]-YTOP[R])+(3-R)*10200)
def at(l):return {'layer':l}
def line(a,b,l='E-FURNITURE'):M.add_line(p(*a),p(*b),dxfattribs=at(l))
def poly(pts,l='E-FURNITURE',closed=False):M.add_lwpolyline([p(*q) for q in pts],close=closed,dxfattribs=at(l))
def box(x,y,w,h,l='E-FURNITURE'):poly([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],l,True)
def curve(pts,l='E-CEILING'):M.add_spline([p(*q) for q in pts],dxfattribs=at(l))
def oval(x,y,rx,ry,l='E-FURNITURE'):
 poly([(x+rx*math.cos(a*math.pi/24),y+ry*math.sin(a*math.pi/24)) for a in range(49)],l,True)
def text(s,x,y,h=230,l='E-TEXT',align=TA.MIDDLE_CENTER):
 t=M.add_text(s,dxfattribs={'height':h,'style':'CJK','layer':l});t.set_placement(p(x,y),align=align);return t
def dim(a,b,base,angle=0):
 d=M.add_linear_dim(base=p(*base),p1=p(*a),p2=p(*b),angle=angle,override={'dimlfac':1,'dimtxt':210,'dimasz':100,'dimexo':90,'dimexe':110,'dimgap':70,'dimtad':1,'dimdec':0,'dimtxsty':'CJK'},dxfattribs=at('E-DIM'));d.render()
def hatchlines(x,y,w,h,step=5,l='E-HATCH'):
 for xx in range(int(x),int(x+w)+1,step):line((xx,y),(xx,y+h),l)
def chair(x,base,w=12,h=22):
 box(x-w*.48,base-h,w*.96,h*.54)
 line((x-w*.45,base-h*.43),(x+w*.45,base-h*.43))
 for dx in [-.4,.4]:line((x+w*dx,base-h*.43),(x+w*dx*1.15,base))
 line((x-w*.5,base-h),(x-w*.55,base-h*.4));line((x+w*.5,base-h),(x+w*.55,base-h*.4))
def table(x,base,w=38,h=23):
 box(x-w*.5,base-h,w,2)
 for dx in [-.35,.35]:line((x+w*dx,base-h+2),(x+w*dx,base))
 line((x-w*.35,base-3),(x+w*.35,base-3))
def group(x,base,w=40):
 table(x,base,w);chair(x-w*.58,base);chair(x+w*.58,base)
 for dx in [-.22,.22]:chair(x+w*dx,base-1,10,22)
def pendant(x,y,length=40):
 line((x,y),(x,y+length),'E-LIGHT');oval(x,y+length+3,2.3,4,'E-LIGHT')
def tree(x,base,h=72,spread=32):
 rng=random.Random(int(x*100+base))
 curve([(x-2,base),(x-1,base-h*.45),(x+2,base-h*.8)],'E-PLANT')
 curve([(x+2,base),(x+3,base-h*.45),(x+1,base-h*.9)],'E-PLANT')
 for _ in range(18):
  t=rng.uniform(.35,.9);sx=x+(rng.random()-.5)*spread;sy=base-h*t
  line((x,base-h*.25),(sx,sy),'E-PLANT')
  for j in range(4):oval(sx+rng.uniform(-5,5),sy+rng.uniform(-4,4),rng.uniform(2,5),rng.uniform(2,4),'E-PLANT')
 for dx in [-8,-3,3,9]:line((x,base-3),(x+dx,base),'E-PLANT')
def rock(x,base,w=22,h=9):
 poly([(x-w/2,base),(x-w*.35,base-h*.65),(x-w*.1,base-h),(x+w*.2,base-h*.7),(x+w*.4,base-h*.8),(x+w*.5,base)],'E-LANDSCAPE')
def waves(x1,x2,ytop,ymax,n=16):
 rng=random.Random(50+R)
 for j in range(n):
  pts=[]
  for i in range(31):
   x=x1+(x2-x1)*i/30
   envelope=(math.sin((x-x1)/(x2-x1)*math.pi))**.7
   y=ytop+2+(ymax-ytop)*(.08+.92*(j+1)/n)*(.48+.22*math.sin(x*.007)+.14*math.sin(x*.018))*envelope
   pts.append((x,y))
  curve(pts)
def landscape(x1,x2,y,amp=20):
 rng=random.Random(99+R)
 for k in range(3):
  pts=[];step=9
  for x in range(int(x1),int(x2)+1,step):
   yy=y+k*6-amp*(.3+.25*math.sin(x*.031)+.2*math.sin(x*.095)+rng.random()*.25)
   pts.append((x,yy))
  poly(pts,'E-LANDSCAPE')
def wallpanel(x,y,w,h):
 box(x,y,w,h,'E-WALL');hatchlines(x+2,y+1,w-4,h-2,4)
def doorway(x,base,w=44,h=88):
 box(x,base-h,w,h,'E-DOOR');box(x+2,base-h+2,w-4,h-2,'E-DOOR');line((x+w*.84,base-h*.5),(x+w*.84,base-h*.45),'E-DOOR')
def column(x,top,base,w=32,roundtop=False):
 if roundtop:
  oval(x+w/2,top+2,w/2,3,'E-COLUMN')
 box(x,top,w,base-top,'E-COLUMN')
 rng=random.Random(int(x))
 for i in range(int(w*(base-top)/55)):
  xx=rng.uniform(x+2,x+w-2);yy=rng.uniform(top+5,base-2)
  line((xx,yy),(xx+.5,yy+1),'E-HATCH')
def bottle(x,y,w=3,h=7):
 poly([(x-w/2,y),(x-w/2,y-h*.65),(x-w*.22,y-h*.75),(x-w*.22,y-h),(x+w*.22,y-h),(x+w*.22,y-h*.75),(x+w*.5,y-h*.65),(x+w*.5,y)],'E-EQUIPMENT',True)
def panel_frame():
 top=YTOP[R];base=YBOT[R]
 box(106,top,1492,base-top,'E-OUTLINE');line((106,base-2),(1598,base-2),'E-OUTLINE')
 box(108,top+2,5,base-top-2,'E-WALL');box(1590,top+2,6,base-top-2,'E-WALL')
 titles=['① 主入口立面图','② 公共咖啡区立面图','③ CAVE沉浸式咖啡厅立面图','④ 会客区及后勤区立面图']
 text(titles[R]+'  原图标注1:50',106,top-17,330,align=TA.MIDDLE_LEFT)
 # Actual segment geometry follows stated lengths; bottom of original has conflicting 33200.
 pos=[106+(v/32200)*1492 for v in [0,6600,13200,19800,26400,32200]]
 for a,b in zip(pos,pos[1:]):dim((a,base),(b,base),(a,base+19))
 dim((106,base),(1598,base),(106,base+38))
 dim((106,base),(106,top),(60,base),90)
 split=3900 if R==0 else 3000
 yy=base-(base-top)*split/5900
 dim((106,base),(106,yy),(79,base),90);dim((106,yy),(106,top),(79,yy),90)
 text('总长冲突：原图33200 / 分段合计32200，本图采用32200；装饰按图估绘。',106,base+61,190,'E-NOTES',TA.MIDDLE_LEFT)
# 1 Entrance
R=0;panel_frame();top=62;base=230
waves(113,1327,63,160,23)
wallpanel(365,126,59,103)
box(264,129,101,100,'E-DOOR');box(272,133,73,94,'E-GLASS');line((307,133),(307,227),'E-GLASS')
line((304,183),(304,194),'E-DOOR');line((310,183),(310,194),'E-DOOR')
tree(214,224,94,57)
for i in range(12):rock(146+i*10,228,15,8+(i%3)*3)
for x in [450,500,550,599,834,881,933,1084,1132,1183]:group(x,227,37)
for x in [848,910,977,1035,1093,1145,1209]:pendant(x,111,44+(x%7))
landscape(427,647,197,22);landscape(808,1222,188,28)
wallpanel(642,143,36,86);wallpanel(716,108,85,121)
curve([(710,126),(722,107),(746,96),(775,96),(801,115)],'E-WALL')
wallpanel(936,108,16,121);wallpanel(1016,94,35,135)
tree(1057,224,90,54);tree(1208,227,69,42)
wallpanel(1204,112,123,117)
for x in range(1330,1463,27):line((x,66),(x,228),'E-WALL')
box(1330,65,133,164,'E-WALL')
text('桃',1411,107,530);text('花',1411,136,530);text('源',1411,165,530)
text('一',1384,124,180);text('处',1384,139,180);text('山',1384,154,180);text('水',1384,169,180)
box(1465,77,123,152,'E-GLASS');line((1527,78),(1527,229),'E-GLASS');line((1548,124),(1548,166),'E-DOOR')
text('luckin coffee | 桃花源',282,98,430)
oval(181,96,12,14,'E-TEXT');poly([(171,90),(166,82),(176,85),(186,85),(194,81),(191,91)],'E-TEXT')
# 2 Public coffee bar
R=1;panel_frame();top=324;base=456
waves(113,1250,325,394,21);landscape(122,1246,428,27)
for x in [264,385,521,648,790,946,1075,1166]:line((x,345),(x,451),'E-GLASS')
tree(192,451,96,53);tree(1119,453,73,43);tree(1220,454,69,42)
for x in [158,209,288,335,383,978,1026,1074,1122,1170,1214]:group(x,454,34)
for x in [273,309,343,378,413,960,1006,1052,1096,1140]:pendant(x,354,37)
# Back counter and full length public bar.
box(439,426,508,28,'E-BAR');box(445,431,497,21,'E-BAR');box(437,422,512,5,'E-BAR')
for x in range(451,941,9):line((x,434),(x,451),'E-HATCH')
for x in range(462,930,39):box(x,446,30,8,'E-BAR')
box(524,368,153,53,'E-WALL');text('luckin coffee',630,387,270);text('luckincoffee',574,401,145)
oval(578,386,10,9,'E-TEXT');poly([(570,382),(566,375),(576,378),(584,378),(591,375),(587,383)],'E-TEXT')
for y in [378,390,401]:line((681,y),(789,y),'E-EQUIPMENT')
for x in range(690,782,11):bottle(x,389,5,8);bottle(x,400,5,8)
for x in [602,624,645,680,700,720,741]:box(x,409,10,13,'E-EQUIPMENT');bottle(x+3,421,4,10)
column(828,327,432,69,True)
for x in [494,722,740]:bottle(x,421,4,12)
wallpanel(1254,338,53,116)
box(1308,341,97,114,'E-WALL')
curve([(1321,453),(1321,401),(1325,381),(1344,365),(1366,365),(1384,378),(1392,397),(1392,453)],'E-WALL')
curve([(1327,451),(1327,401),(1332,384),(1348,371),(1365,371),(1380,382),(1386,399),(1386,451)],'E-WALL')
group(1355,454,41)
box(1408,340,183,115,'E-WALL');oval(1477,390,44,36,'E-WALL');oval(1477,390,42,35,'E-WALL')
tree(1483,447,52,30);group(1478,451,45);tree(1550,450,40,26)
# 3 Cave elevation
R=2;panel_frame();top=540;base=668
waves(118,1240,541,597,25)
wallpanel(124,558,138,108);column(264,546,667,33)
for x in [177,195,219,241]:rock(x,665,18,12)
landscape(302,1234,630,34);landscape(316,1222,645,22)
for x in range(319,1208,22):chair(x,667,15,17)
for x in range(341,1201,73):table(x,667,50,18)
column(731,569,667,45,True)
tree(329,661,99,49);tree(1183,663,106,78)
for x in list(range(301,419,15))+list(range(1090,1228,14)):rock(x,665,25,8+(x%13))
wallpanel(1253,554,49,112);box(1305,555,123,111,'E-WALL')
landscape(1310,1426,619,20);tree(1351,651,47,24)
box(1319,650,86,15,'E-FURNITURE')
for x in [1322,1346,1370,1394]:box(x,648,20,4,'E-FURNITURE')
box(1432,554,60,112,'E-GLASS');curve([(1434,586),(1454,573),(1470,578),(1489,568)],'E-WALL')
for x in [1435,1454,1477,1490]:line((x,575),(x,665),'E-WALL')
doorway(1541,667,42,91)
# 4 Reception / service zone
R=3;panel_frame();top=752;base=874
waves(115,880,753,807,19);landscape(116,879,849,24)
for x in [201,324,512,679,860]:line((x,777),(x,869),'E-GLASS')
for x in [153,201,247,365,411,457,699,839]:group(x,873,36)
for x in [172,205,367,407,443,492]:pendant(x,782,33)
tree(498,871,50,32);tree(804,871,59,36)
# Decorative arched display shelf.
curve([(544,850),(544,811),(552,786),(573,774),(593,775),(619,789),(634,811),(634,850)],'E-WALL')
line((544,850),(634,850),'E-WALL')
for y in [799,816,833]:line((548,y),(629,y),'E-EQUIPMENT')
for x in [558,574,590,606,622]:
 for y in [814,831,848]:bottle(x,y,5,9)
for x in [563,586,609]:bottle(x,797,5,9)
oval(780,823,43,40,'E-WALL');oval(780,823,41,38,'E-WALL');line((773,786),(773,861),'E-GLASS')
column(879,754,874,10)
# Blank service walls and real openings.
for a,b in [(890,1126),(1133,1291),(1298,1590)]:box(a,758,b-a,115,'E-WALL')
doorway(1072,873,45,91);doorway(1135,873,20,83)
box(1154,839,137,34,'E-EQUIPMENT')
for x in [1177,1204,1232]:oval(x,850,6,10,'E-EQUIPMENT');box(x-5,841,10,3,'E-EQUIPMENT')
box(1247,838,41,5,'E-EQUIPMENT');box(1250,844,35,29,'E-EQUIPMENT')
for x in [1257,1277]:line((x,834),(x,840),'E-EQUIPMENT')
doorway(1300,873,42,91);box(1347,783,76,55,'E-GLASS');line((1384,784),(1384,837),'E-GLASS');tree(1380,837,48,27)
for x,w in [(1446,32),(1512,30),(1547,33)]:doorway(x,873,w,91)
# Sheet info in model space; original 1:50 is a reference only, actual print scale set by user.
text('四组室内立面图 | 单位mm | 模型1:1 | 兼容AutoCAD 2021',106,984,310,'E-TEXT',TA.MIDDLE_LEFT)
text('依据截图人工重建。墙面山水、树木、家具、吊顶为简化估绘；文字及面积不作为实测依据。',106,1009,220,'E-NOTES',TA.MIDDLE_LEFT)
text('总高采用5900；①分高3900+2000，其余暂按3000+2900。模糊标注及构造细节须复核。',106,1033,220,'E-NOTES',TA.MIDDLE_LEFT)
# Border in model coordinates, covers every panel.
M.add_lwpolyline([(-1800,-8500),(33200,-8500),(33200,38400),(-1800,38400)],close=True,dxfattribs=at('E-SHEET'))
D.set_modelspace_vport(height=49000,center=(15700,15000))
f=P/'cafe_four_elevations.dxf';D.saveas(f)
T=ezdxf.readfile(f);a=T.audit();assert not a.errors
report={'dxf_version':T.dxfversion,'units':'mm','panels':4,'adopted_width':32200,'adopted_height':5900,'original_total_width':33200,'audit_errors':len(a.errors),'audit_fixes':len(a.fixes),'entities':len(T.modelspace()),'types':dict(collections.Counter(e.dxftype() for e in T.modelspace())),'layers':dict(collections.Counter(e.dxf.layer for e in T.modelspace()))}
assert report['types']['DIMENSION']==36
assert not any(e.dxftype() in ['IMAGE','PDFUNDERLAY'] for e in T.modelspace())
(P/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(report)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import RenderContext,Frontend
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import Configuration,ColorPolicy,BackgroundPolicy
fig=plt.figure(figsize=(16,20));ax=fig.add_axes([.01,.01,.98,.98])
Frontend(RenderContext(T),MatplotlibBackend(ax),config=Configuration(background_policy=BackgroundPolicy.WHITE,color_policy=ColorPolicy.BLACK,lineweight_scaling=.65,min_lineweight=.06)).draw_layout(T.modelspace(),finalize=True)
fig.savefig(P/'elevations_preview.png',dpi=150,facecolor='white')
fig.savefig(P/'elevations_preview.pdf',facecolor='white')
print('Rendered')
